<?php
if (($argv[1] ?? '') === '--missing-captcha') {
    $_SERVER['REQUEST_METHOD'] = 'POST';
    $_POST = ['username' => 'test', 'password' => 'test'];
    register_shutdown_function(function () {
        if (($_SESSION['error'] ?? '') !== 'Please complete the reCAPTCHA verification.') {
            fwrite(STDERR, "Missing CAPTCHA was not rejected.\n");
            exit(1);
        }
        echo "Missing CAPTCHA rejected before database/password authentication.\n";
    });
    require __DIR__ . '/../includes/auth.php';
    exit(1);
}
require_once __DIR__ . '/../includes/security.php';
function check_security($condition, $message) {
    if (!$condition) throw new RuntimeException($message);
}
cropsense_start_secure_session();
$_SESSION = ['pending_2fa_user_id' => 1];
check_security(!cropsense_enforce_session_timeout(), 'Pending OTP must not authenticate.');
check_security(!isset($_SESSION['last_activity']), 'Pending OTP must not start activity.');
$_SESSION = ['user_id' => 1, 'last_activity' => time() - 100];
$last = $_SESSION['last_activity'];
check_security(cropsense_enforce_session_timeout(null, false), 'Valid session rejected.');
check_security($_SESSION['last_activity'] === $last, 'Background check refreshed activity.');
check_security(cropsense_enforce_session_timeout(), 'Active page rejected.');
check_security($_SESSION['last_activity'] >= time() - 1, 'Page failed to refresh activity.');
$_SESSION = ['user_id' => 1, 'username' => 'test', 'role' => 'Administrator',
    'pending_2fa_user_id' => 2, 'last_activity' => time() - 1801];
$oldId = session_id();
check_security(!cropsense_enforce_session_timeout(), 'Expired session revived.');
check_security($_SESSION === [], 'Expired authentication or OTP state was retained.');
check_security(session_status() !== PHP_SESSION_ACTIVE, 'Expired session was not destroyed.');
check_security(session_id() !== $oldId, 'Expired session ID reused.');
check_security(session_id() === '', 'Expired session ID retained.');
check_security(!cropsense_enforce_session_timeout(), 'Expired session authenticated again.');
check_security(!cropsense_verify_recaptcha(''), 'Missing CAPTCHA accepted.');
check_security(!cropsense_verify_recaptcha(['invalid']), 'Malformed CAPTCHA accepted.');
cropsense_clear_session();
echo "Session security checks passed.\n";
