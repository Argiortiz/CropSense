<?php
require_once __DIR__ . '/../includes/security.php';
function recaptcha_check($condition, $message) {
    if (!$condition) throw new RuntimeException($message);
}
foreach (['localhost', 'localhost:8080', 'cropsense.site', 'www.cropsense.site'] as $host) {
    $_SERVER['HTTP_HOST'] = $host;
    $hostname = explode(':', $host)[0];
    recaptcha_check(cropsense_recaptcha_response_is_valid(['success' => true, 'hostname' => $hostname]), 'Valid deployment rejected');
    recaptcha_check(!cropsense_recaptcha_response_is_valid(['success' => true, 'hostname' => 'attacker.example']), 'Arbitrary hostname accepted');
    recaptcha_check(!cropsense_recaptcha_response_is_valid(['success' => true, 'hostname' => 'localhost:8080']), 'Malformed Google hostname accepted');
    recaptcha_check(!cropsense_recaptcha_response_is_valid(['success' => 'true', 'hostname' => $hostname]), 'Nonboolean success accepted');
    recaptcha_check(!cropsense_recaptcha_response_is_valid(['success' => true, 'hostname' => $hostname, 'error-codes' => ['timeout-or-duplicate']]), 'Rejected token accepted');
}
$_SERVER['HTTP_HOST'] = 'cropsense.site';
recaptcha_check(!cropsense_recaptcha_response_is_valid(['success' => true, 'hostname' => 'localhost']), 'Local token accepted in production');
recaptcha_check(!cropsense_recaptcha_response_is_valid(['success' => true, 'hostname' => []]), 'Malformed hostname accepted');
recaptcha_check(cropsense_recaptcha_response_is_valid(['success' => true]), 'Optional hostname incorrectly required');
recaptcha_check(!cropsense_verify_recaptcha(''), 'Empty token accepted');
recaptcha_check(!cropsense_verify_recaptcha([]), 'Array token accepted');
recaptcha_check(!cropsense_verify_recaptcha(str_repeat('x', 8193)), 'Oversized token accepted');
$login = file_get_contents(__DIR__ . '/../login.php');
recaptcha_check(substr_count($login, 'https://www.google.com/recaptcha/api.js') === 1, 'Duplicate loader');
recaptcha_check(strpos($login, 'reCAPTCHA is not configured.') !== false, 'Missing setup message');
$example = require __DIR__ . '/../config/security.local.example.php';
recaptcha_check($example['recaptcha_site_key'] === '' && $example['recaptcha_secret_key'] === '', 'Example contains configured CAPTCHA keys');
echo "reCAPTCHA security checks passed.\n";
