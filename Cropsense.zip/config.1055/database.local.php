<?php

return [
    "host" => "localhost",
    "dbname" => "u910796166_cropsense_db",
    "username" => "u910796166_cs_admin",
    "password" => "CropSense@2026",
];
