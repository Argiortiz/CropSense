<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
<script src="/assets/js/preferences.js?v=20260716-command2"></script>

</body>

</html>
