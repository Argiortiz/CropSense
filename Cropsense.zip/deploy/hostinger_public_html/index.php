<?php
require_once __DIR__ . "/includes/security.php";

cropsense_start_secure_session();

if (isset($_SESSION["user_id"])) {
    header("Location: dashboard.php");
    exit();
}

header("Location: login.php");
exit();
?>
