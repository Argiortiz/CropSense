<?php
require_once "includes/session.php";
require_once "includes/roles.php";
require_once "includes/device_status.php";
require_once "config/database.php";

$latestSensorReading = null;
$sensorLiveThresholdSeconds = 10;
$sensorIsLive = false;
$sensorAgeSeconds = null;
$sensorStatusLabel = "Sensor Offline";
$sensorStatusClass = "is-offline";

$sensorSql = "
    SELECT
        sr.soil_moisture,
        sr.soil_ph,
        sr.soil_ec,
        sr.nitrogen,
        sr.phosphorus,
        sr.potassium,
        sr.temperature,
        sr.humidity,
        sr.created_at,
        TIMESTAMPDIFF(SECOND, sr.created_at, NOW()) AS age_seconds,
        d.device_name
    FROM sensor_readings sr
    INNER JOIN devices d ON d.id = sr.device_id
    ORDER BY sr.created_at DESC, sr.id DESC
    LIMIT 1
";

$sensorResult = $conn->query($sensorSql);

if ($sensorResult && $sensorResult->num_rows > 0) {
    $latestSensorReading = $sensorResult->fetch_assoc();
    $sensorAgeSeconds = (int) ($latestSensorReading["age_seconds"] ?? 0);
    $sensorIsLive = $sensorAgeSeconds <= $sensorLiveThresholdSeconds;
    $sensorStatusLabel = $sensorIsLive ? "Sensor Live" : "Sensor Offline";
    $sensorStatusClass = $sensorIsLive ? "" : "is-offline";
}

function dashboard_number($reading, $key, $digits = 0)
{
    if (!$reading || !isset($reading[$key]) || !is_numeric($reading[$key])) {
        return "--";
    }

    return number_format((float) $reading[$key], $digits);
}

function dashboard_relative_time($seconds)
{
    if ($seconds === null) {
        return "waiting for device input";
    }

    if ($seconds < 60) {
        return "just now";
    }

    if ($seconds < 3600) {
        return floor($seconds / 60) . " min ago";
    }

    return floor($seconds / 3600) . " hr ago";
}

function dashboard_status_text($reading, $ageSeconds, $liveText = "Updated")
{
    if (!$reading) {
        return "Awaiting sensor reading";
    }

    $prefix = $ageSeconds !== null && $ageSeconds <= 10 ? $liveText : "Last reading";
    return $prefix . " " . dashboard_relative_time($ageSeconds);
}

$sensorUpdatedText = dashboard_status_text($latestSensorReading, $sensorAgeSeconds);
$sensorPh = $latestSensorReading && (float) $latestSensorReading["soil_ph"] > 0
    ? dashboard_number($latestSensorReading, "soil_ph", 1)
    : "--";
$sensorPhStatus = $sensorPh === "--" ? "pH sensor not connected" : $sensorUpdatedText;
$sensorEc = dashboard_number($latestSensorReading, "soil_ec");
$sensorEcStatus = $latestSensorReading ? $sensorUpdatedText : "Electrical conductivity";
$sensorNpk = dashboard_number($latestSensorReading, "nitrogen")
    . " / " . dashboard_number($latestSensorReading, "phosphorus")
    . " / " . dashboard_number($latestSensorReading, "potassium");
$sensorActivityTitle = $latestSensorReading
    ? ($sensorIsLive ? "Live sensor reading received" : "Sensor offline")
    : "Sensor readings pending";
$sensorActivityDetail = $latestSensorReading
    ? (($latestSensorReading["device_name"] ?? "CropSense device") . " " . ($sensorIsLive ? "updated " : "last updated ") . dashboard_relative_time($sensorAgeSeconds))
    : "Waiting for device input";

include "includes/header.php";
?>

<div class="dashboard-shell">
    <?php include "includes/sidebar.php"; ?>

    <main class="dashboard-main">
        <?php include "includes/navbar.php"; ?>

        <section class="dashboard-hero">
            <div class="hero-copy">
                <span class="hero-badge">
                    <i class="bi bi-stars"></i>
                    Morning field overview
                </span>
                <h2>Your farm conditions, beautifully in focus.</h2>
                <p>
                    Watch soil health, nutrient balance, device activity, and crop signals
                    from one calm command center built for smarter field decisions.
                </p>

                <div class="hero-metrics" aria-label="Dashboard summary">
                    <div>
                        <strong>5</strong>
                        <span>Field Signals</span>
                    </div>
                    <div>
                        <strong><?php echo (int) $deviceSummary['active_count']; ?></strong>
                        <span>Devices Online</span>
                    </div>
                    <div>
                        <strong>2.0</strong>
                        <span>CropSense Version</span>
                    </div>
                </div>
            </div>

            <div class="hero-orbit" aria-label="Field readiness preview">
                <div class="orbit-ring">
                    <img src="assets/img/cropsense-logo.svg" alt="">
                </div>

                <div class="hero-weather">
                    <i class="bi bi-brightness-high"></i>
                    <div>
                        <small>Field Mood</small>
                        <strong>Ready for today's scan</strong>
                    </div>
                </div>
            </div>
        </section>

        <section class="sensor-grid" aria-label="Sensor readings" data-live-dashboard>
            <article class="sensor-card moisture" data-sensor-card="moisture">
                <div class="sensor-icon">
                    <i class="bi bi-droplet-half"></i>
                </div>
                <div>
                    <span>Soil Moisture</span>
                    <strong data-reading="soil_moisture"><?php echo dashboard_number($latestSensorReading, "soil_moisture"); ?>%</strong>
                    <small data-reading-status="soil_moisture"><?php echo htmlspecialchars($sensorUpdatedText); ?></small>
                </div>
                <span class="sensor-glow"></span>
            </article>

            <article class="sensor-card ph" data-sensor-card="ph">
                <div class="sensor-icon">
                    <i class="bi bi-eyedropper"></i>
                </div>
                <div>
                    <span>Soil pH</span>
                    <strong data-reading="soil_ph"><?php echo $sensorPh; ?></strong>
                    <small data-reading-status="soil_ph"><?php echo htmlspecialchars($sensorPhStatus); ?></small>
                </div>
                <span class="sensor-glow"></span>
            </article>

            <article class="sensor-card ec" data-sensor-card="ec">
                <div class="sensor-icon">
                    <i class="bi bi-lightning-charge"></i>
                </div>
                <div>
                    <span>Soil EC</span>
                    <strong data-reading="soil_ec"><?php echo $sensorEc; ?></strong>
                    <small data-reading-status="soil_ec"><?php echo htmlspecialchars($sensorEcStatus); ?></small>
                </div>
                <span class="sensor-glow"></span>
            </article>

            <article class="sensor-card npk nutrient-card" data-sensor-card="npk">
                <div class="sensor-icon">
                    <i class="bi bi-gem"></i>
                </div>
                <div>
                    <span>NPK Sensor</span>
                    <strong data-reading="npk"><?php echo $sensorNpk; ?></strong>
                    <small data-reading-status="npk"><?php echo $latestSensorReading ? "N, P, K mg/kg " . htmlspecialchars($sensorUpdatedText) : "Nitrogen, phosphorus, potassium"; ?></small>
                    <div class="nutrient-values" aria-label="NPK nutrient values">
                        <span><b>N</b> <output data-reading="nitrogen"><?php echo dashboard_number($latestSensorReading, "nitrogen"); ?></output></span>
                        <span><b>P</b> <output data-reading="phosphorus"><?php echo dashboard_number($latestSensorReading, "phosphorus"); ?></output></span>
                        <span><b>K</b> <output data-reading="potassium"><?php echo dashboard_number($latestSensorReading, "potassium"); ?></output></span>
                    </div>
                </div>
                <span class="sensor-glow"></span>
            </article>

            <article class="sensor-card temperature" data-sensor-card="temperature">
                <div class="sensor-icon">
                    <i class="bi bi-thermometer-sun"></i>
                </div>
                <div>
                    <span>Temperature</span>
                    <strong data-reading="temperature"><?php echo dashboard_number($latestSensorReading, "temperature", 1); ?> C</strong>
                    <small data-reading-status="temperature"><?php echo $latestSensorReading ? htmlspecialchars($sensorUpdatedText) : "Field climate reading"; ?></small>
                </div>
                <span class="sensor-glow"></span>
            </article>

            <article class="sensor-card humidity" data-sensor-card="humidity">
                <div class="sensor-icon">
                    <i class="bi bi-cloud-drizzle"></i>
                </div>
                <div>
                    <span>Humidity</span>
                    <strong data-reading="humidity"><?php echo dashboard_number($latestSensorReading, "humidity"); ?>%</strong>
                    <small data-reading-status="humidity"><?php echo $latestSensorReading ? htmlspecialchars($sensorUpdatedText) : "Air moisture status"; ?></small>
                </div>
                <span class="sensor-glow"></span>
            </article>
        </section>

        <section class="dashboard-content">
            <article class="recommendation-panel">
                <div class="section-heading">
                    <div>
                        <span>AI Recommendation</span>
                        <h3>Best Crop Match</h3>
                    </div>
                    <i class="bi bi-flower2"></i>
                </div>

                <div class="crop-match">
                    <div class="match-ring">
                        <strong data-recommendation-score>--</strong>
                        <small>Score</small>
                    </div>
                    <div>
                        <h4 data-recommendation-title>No crop selected yet</h4>
                        <p>
                            Once sensor data is available, CropSense can highlight crops
                            that fit the current soil and climate profile.
                        </p>
                    </div>
                </div>

                <div class="field-visual" aria-label="Field readiness bars">
                    <div>
                        <span>Moisture</span>
                        <strong data-readiness-bar="moisture"></strong>
                    </div>
                    <div>
                        <span>Nutrients</span>
                        <strong data-readiness-bar="nutrients"></strong>
                    </div>
                    <div>
                        <span>Climate</span>
                        <strong data-readiness-bar="climate"></strong>
                    </div>
                </div>

                <div class="recommendation-list">
                    <div>
                        <i class="bi bi-check2-circle"></i>
                        Connect soil sensor
                    </div>
                    <div>
                        <i class="bi bi-check2-circle"></i>
                        Collect field readings
                    </div>
                    <div>
                        <i class="bi bi-check2-circle"></i>
                        Generate crop match
                    </div>
                </div>
            </article>

            <article class="activity-panel">
                <div class="section-heading">
                    <div>
                        <span>Today</span>
                        <h3>Farm Activity</h3>
                    </div>
                    <i class="bi bi-activity"></i>
                </div>

                <div class="timeline">
                    <div>
                        <span></span>
                        <div>
                            <strong>Dashboard opened</strong>
                            <small>System ready for field review</small>
                        </div>
                    </div>
                    <div>
                        <span></span>
                        <div>
                            <strong data-activity-title><?php echo htmlspecialchars($sensorActivityTitle); ?></strong>
                            <small data-activity-detail><?php echo htmlspecialchars($sensorActivityDetail); ?></small>
                        </div>
                    </div>
                    <div>
                        <span></span>
                        <div>
                            <strong>Reports available soon</strong>
                            <small>Charts will appear after data capture</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="quick-actions">
                <div class="section-heading">
                    <div>
                        <span>Tools</span>
                        <h3>Quick Actions</h3>
                    </div>
                </div>

                <?php if (cropsense_is_admin()) : ?>
                    <a href="user_management.php">
                        <i class="bi bi-person-plus"></i>
                        Insert User
                    </a>
                <?php endif; ?>

                <a href="collected_data.php">
                    <i class="bi bi-table"></i>
                    View Collected Data
                </a>

                <a href="export_collected_data.php">
                    <i class="bi bi-file-earmark-excel"></i>
                    Download Data
                </a>
            </article>
        </section>
    </main>
</div>

<script src="assets/js/dashboard.js"></script>
<?php include "includes/footer.php"; ?>
