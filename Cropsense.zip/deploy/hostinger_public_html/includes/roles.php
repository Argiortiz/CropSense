<?php

if (!function_exists('cropsense_current_role')) {
    function cropsense_admin_emails()
    {
        return [
            'razelljay@isu.edu.ph',
            'gemmarose.e.maranan@isu.edu.ph',
            'shielamae.d.carino@isu.edu.ph',
        ];
    }

    function cropsense_email_can_be_admin($email)
    {
        return in_array(strtolower(trim((string) $email)), cropsense_admin_emails(), true);
    }

    function cropsense_current_role()
    {
        return $_SESSION['role'] ?? '';
    }
}

if (!function_exists('cropsense_is_admin')) {
    function cropsense_is_admin()
    {
        return cropsense_current_role() === 'Administrator';
    }
}

if (!function_exists('cropsense_require_admin')) {
    function cropsense_require_admin()
    {
        if (!cropsense_is_admin()) {
            http_response_code(403);
            header('Location: dashboard.php');
            exit();
        }
    }
}

?>
