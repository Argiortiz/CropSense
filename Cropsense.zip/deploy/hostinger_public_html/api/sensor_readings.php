<?php
require_once "../config/database.php";
require_once "../includes/security.php";

cropsense_apply_security_headers("api");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-CropSense-Key");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    exit;
}

function respond_json($payload, $statusCode = 200)
{
    http_response_code($statusCode);
    echo json_encode($payload);
    exit;
}

function request_payload()
{
    $contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);

    if ($contentLength > CROPSENSE_MAX_SENSOR_PAYLOAD_BYTES) {
        respond_json(["ok" => false, "error" => "Sensor payload is too large."], 413);
    }

    $payload = $_POST;
    $rawBody = file_get_contents("php://input");

    if ($rawBody !== false && trim($rawBody) !== "") {
        $json = json_decode($rawBody, true);

        if (json_last_error() === JSON_ERROR_NONE && is_array($json)) {
            $payload = array_merge($payload, $json);
        } else {
            respond_json(["ok" => false, "error" => "Invalid JSON payload."], 400);
        }
    }

    return $payload;
}

function numeric_value($payload, $keys, $default = null)
{
    foreach ($keys as $key) {
        if (isset($payload[$key]) && is_numeric($payload[$key])) {
            return (float) $payload[$key];
        }
    }

    return $default;
}

function text_value($payload, $keys, $default)
{
    foreach ($keys as $key) {
        if (isset($payload[$key]) && trim((string) $payload[$key]) !== "") {
            return trim((string) $payload[$key]);
        }
    }

    return $default;
}

function require_range($value, $min, $max, $label)
{
    if ($value === null) {
        return;
    }

    if ($value < $min || $value > $max) {
        respond_json([
            "ok" => false,
            "error" => "{$label} is outside the accepted range."
        ], 422);
    }
}

function first_id($conn, $table)
{
    $safeTable = "`" . str_replace("`", "``", $table) . "`";
    $result = $conn->query("SELECT id FROM {$safeTable} ORDER BY id ASC LIMIT 1");

    if ($result && $row = $result->fetch_assoc()) {
        return (int) $row["id"];
    }

    return null;
}

function ensure_default_farm($conn)
{
    $existingId = first_id($conn, "farms");

    if ($existingId) {
        return $existingId;
    }

    $stmt = $conn->prepare(
        "INSERT INTO farms (farm_name, owner_name, barangay, municipality, province, area_hectares, soil_type, remarks)
         VALUES ('CropSense Demo Farm', 'CropSense User', 'Field Station', 'Echague', 'Isabela', 1.00, 'Unspecified', 'Automatically created for incoming sensor readings')"
    );

    if (!$stmt || !$stmt->execute()) {
        respond_json(["ok" => false, "error" => "Unable to create default farm."], 500);
    }

    return (int) $conn->insert_id;
}

function ensure_device($conn, $payload)
{
    $deviceCode = text_value($payload, ["device_code", "deviceCode"], "CROP-ESP32-001");
    $deviceName = text_value($payload, ["device_name", "deviceName"], "CropSense ESP32");
    $location = text_value($payload, ["location"], "Field Station");

    $stmt = $conn->prepare("SELECT id FROM devices WHERE device_code = ? LIMIT 1");
    $stmt->bind_param("s", $deviceCode);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $deviceId = (int) $row["id"];
        $update = $conn->prepare("UPDATE devices SET status = 'Online', last_seen = NOW(), device_name = ?, location = ? WHERE id = ?");
        $update->bind_param("ssi", $deviceName, $location, $deviceId);
        $update->execute();

        return $deviceId;
    }

    $insert = $conn->prepare(
        "INSERT INTO devices (device_name, device_code, location, status, last_seen)
         VALUES (?, ?, ?, 'Online', NOW())"
    );
    $insert->bind_param("sss", $deviceName, $deviceCode, $location);

    if (!$insert->execute()) {
        respond_json(["ok" => false, "error" => "Unable to register device."], 500);
    }

    return (int) $conn->insert_id;
}

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $liveThresholdSeconds = 10;
    $sql = "
        SELECT
            sr.id,
            sr.soil_moisture,
            sr.soil_ph,
            sr.soil_ec,
            sr.nitrogen,
            sr.phosphorus,
            sr.potassium,
            sr.temperature,
            sr.humidity,
            sr.created_at,
            TIMESTAMPDIFF(SECOND, sr.created_at, NOW()) AS age_seconds,
            d.device_name,
            d.device_code,
            d.status AS device_status,
            d.last_seen,
            f.farm_name
        FROM sensor_readings sr
        INNER JOIN devices d ON d.id = sr.device_id
        INNER JOIN farms f ON f.id = sr.farm_id
        ORDER BY sr.created_at DESC, sr.id DESC
        LIMIT 1
    ";

    $result = $conn->query($sql);

    if (!$result) {
        respond_json(["ok" => false, "error" => "Unable to load sensor readings."], 500);
    }

    $reading = $result->fetch_assoc();
    if ($reading) {
        $ageSeconds = (int) ($reading["age_seconds"] ?? 0);
        $isLive = $ageSeconds <= $liveThresholdSeconds;

        $reading["is_live"] = $isLive;
        $reading["live_threshold_seconds"] = $liveThresholdSeconds;
        $reading["connection_status"] = $isLive ? "Live" : "Offline";

        if (!$isLive && ($reading["device_status"] ?? "") === "Online") {
            $deviceCode = $reading["device_code"];
            $update = $conn->prepare("UPDATE devices SET status = 'Offline' WHERE device_code = ? AND last_seen < DATE_SUB(NOW(), INTERVAL ? SECOND)");
            $update->bind_param("si", $deviceCode, $liveThresholdSeconds);
            $update->execute();
            $reading["device_status"] = "Offline";
        }
    }

    respond_json(["ok" => true, "data" => $reading ?: null]);
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    respond_json(["ok" => false, "error" => "Method not allowed."], 405);
}

$payload = request_payload();

if (!cropsense_device_api_key_is_valid($payload)) {
    respond_json(["ok" => false, "error" => "Unauthorized sensor device."], 401);
}

$soilMoisture = numeric_value($payload, ["soil_moisture", "soilMoisture", "moisture"]);
$temperature = numeric_value($payload, ["temperature", "temp"]);
$humidity = numeric_value($payload, ["humidity"]);
$nitrogen = numeric_value($payload, ["nitrogen", "n"], 0);
$phosphorus = numeric_value($payload, ["phosphorus", "p"], 0);
$potassium = numeric_value($payload, ["potassium", "k"], 0);
$soilPh = numeric_value($payload, ["soil_ph", "soilPh", "ph"], 0);
$soilEc = numeric_value($payload, ["soil_ec", "soilEc", "ec"], 0);

if ($soilMoisture === null || $temperature === null || $humidity === null) {
    respond_json([
        "ok" => false,
        "error" => "Missing required values. Send soil_moisture, temperature, and humidity."
    ], 422);
}

require_range($soilMoisture, 0, 100, "Soil moisture");
require_range($temperature, -20, 80, "Temperature");
require_range($humidity, 0, 100, "Humidity");
require_range($nitrogen, 0, 10000, "Nitrogen");
require_range($phosphorus, 0, 10000, "Phosphorus");
require_range($potassium, 0, 10000, "Potassium");
require_range($soilPh, 0, 14, "Soil pH");
require_range($soilEc, 0, 20000, "Soil EC");

$soilMoisture = max(0, min(100, $soilMoisture));
$humidity = max(0, min(100, $humidity));
$soilPh = max(0, min(14, $soilPh));
$soilEc = max(0, min(20000, $soilEc));

$farmId = isset($payload["farm_id"]) && is_numeric($payload["farm_id"])
    ? (int) $payload["farm_id"]
    : ensure_default_farm($conn);
$deviceId = ensure_device($conn, $payload);

$stmt = $conn->prepare(
    "INSERT INTO sensor_readings (
        device_id,
        farm_id,
        soil_moisture,
        soil_ph,
        soil_ec,
        nitrogen,
        phosphorus,
        potassium,
        temperature,
        humidity
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
);

if (!$stmt) {
    respond_json(["ok" => false, "error" => "Unable to prepare sensor reading insert."], 500);
}

$stmt->bind_param(
    "iidddddddd",
    $deviceId,
    $farmId,
    $soilMoisture,
    $soilPh,
    $soilEc,
    $nitrogen,
    $phosphorus,
    $potassium,
    $temperature,
    $humidity
);

if (!$stmt->execute()) {
    respond_json(["ok" => false, "error" => "Unable to save sensor reading."], 500);
}

respond_json([
    "ok" => true,
    "message" => "Sensor reading saved.",
    "reading_id" => (int) $conn->insert_id,
    "device_id" => $deviceId,
    "farm_id" => $farmId
], 201);
