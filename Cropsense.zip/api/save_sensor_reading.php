<?php
require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../includes/security.php";
require_once __DIR__ . "/../includes/storage_crypto.php";

cropsense_apply_security_headers("api");
header("Allow: POST");

function save_response($body, $status = 200)
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST") {
    save_response(["ok" => false, "error" => "Method not allowed."], 405);
}

$contentType = strtolower(trim(explode(";", $_SERVER["CONTENT_TYPE"] ?? "")[0]));
$raw = file_get_contents("php://input");

if (strlen((string) $raw) > CROPSENSE_MAX_SENSOR_PAYLOAD_BYTES) {
    save_response(["ok" => false, "error" => "Request body is too large."], 413);
}

if ($contentType === "application/json") {
    $payload = json_decode((string) $raw, true);
    if (!is_array($payload) || json_last_error() !== JSON_ERROR_NONE) {
        save_response(["ok" => false, "error" => "Malformed JSON request."], 400);
    }
} else {
    $payload = $_POST;
}

if (CROPSENSE_DEVICE_API_KEY === "") {
    error_log("CropSense sensor API key is not configured.");
    save_response(["ok" => false, "error" => "Sensor API is not configured."], 503);
}

if (!cropsense_device_api_key_is_valid($payload)) {
    save_response(["ok" => false, "error" => "Unauthorized."], 401);
}

[$deviceCode, $values] = cropsense_validate_sensor_values($payload, "save_response");

$deviceName = substr(trim((string) ($payload["device_name"] ?? $deviceCode)), 0, 100);
$location = substr(trim((string) ($payload["location"] ?? "Field Station")), 0, 150);

try {
    $stored = cropsense_store_encrypted_reading(
        $conn,
        $deviceCode,
        $deviceName,
        $location,
        $values
    );
} catch (Throwable $error) {
    error_log("CropSense AES database insert failed: " . $error->getMessage());
    save_response(["ok" => false, "error" => "Unable to store encrypted sensor reading."], 500);
}

save_response([
    "ok" => true,
    "message" => "Sensor reading encrypted with AES-256-GCM before database storage.",
    "id" => $stored["reading_id"],
    "device_id" => $deviceCode,
    "database_encrypted" => true,
    "encryption" => "AES-256-GCM",
], 201);
