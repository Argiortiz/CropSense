<?php
require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../includes/security.php";
require_once __DIR__ . "/../includes/storage_crypto.php";

cropsense_apply_security_headers("api");
header("Allow: POST");

function aes_save_response($body, $status = 200)
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST") {
    aes_save_response(["ok" => false, "error" => "Method not allowed."], 405);
}

$raw = file_get_contents("php://input");
if (!is_string($raw) || $raw === "") {
    aes_save_response(["ok" => false, "error" => "Empty request body."], 400);
}

if (strlen($raw) > 8192) {
    aes_save_response(["ok" => false, "error" => "Request body is too large."], 413);
}

$envelope = json_decode($raw, true);
if (!is_array($envelope) || json_last_error() !== JSON_ERROR_NONE) {
    aes_save_response(["ok" => false, "error" => "Malformed JSON envelope."], 400);
}

if (CROPSENSE_DEVICE_API_KEY === "") {
    aes_save_response(["ok" => false, "error" => "Sensor API is not configured."], 503);
}

if (!cropsense_device_api_key_is_valid($envelope)) {
    aes_save_response(["ok" => false, "error" => "Unauthorized."], 401);
}

foreach (["version", "device_id", "timestamp_ms", "message_id", "iv", "ciphertext", "tag"] as $field) {
    if (!array_key_exists($field, $envelope) || $envelope[$field] === "" || $envelope[$field] === null) {
        aes_save_response(["ok" => false, "error" => "Missing envelope field: {$field}."], 422);
    }
}

if ((int) $envelope["version"] !== 1) {
    aes_save_response(["ok" => false, "error" => "Unsupported envelope version."], 422);
}

$deviceCode = trim((string) $envelope["device_id"]);
if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]{0,49}$/', $deviceCode)) {
    aes_save_response(["ok" => false, "error" => "Invalid device_id."], 422);
}

$messageId = trim((string) $envelope["message_id"]);
if (!preg_match('/^[a-fA-F0-9]{32}$/', $messageId)) {
    aes_save_response(["ok" => false, "error" => "Invalid message_id."], 422);
}

if (!is_numeric($envelope["timestamp_ms"])) {
    aes_save_response(["ok" => false, "error" => "Invalid timestamp_ms."], 422);
}

$timestampMs = (int) $envelope["timestamp_ms"];
$serverNowMs = (int) round(microtime(true) * 1000);

if (abs($serverNowMs - $timestampMs) > 5 * 60 * 1000) {
    aes_save_response(["ok" => false, "error" => "Sensor timestamp is outside the allowed window."], 409);
}

$iv = base64_decode((string) $envelope["iv"], true);
$ciphertext = base64_decode((string) $envelope["ciphertext"], true);
$tag = base64_decode((string) $envelope["tag"], true);

if ($iv === false || strlen($iv) !== 12) {
    aes_save_response(["ok" => false, "error" => "Invalid transport AES-GCM IV."], 422);
}
if ($tag === false || strlen($tag) !== 16) {
    aes_save_response(["ok" => false, "error" => "Invalid transport AES-GCM tag."], 422);
}
if ($ciphertext === false || $ciphertext === "") {
    aes_save_response(["ok" => false, "error" => "Invalid transport ciphertext."], 422);
}

$aad = "v1|" . $deviceCode . "|" . (string) $timestampMs . "|" . $messageId;

try {
    $transportKey = cropsense_transport_aes_key();
} catch (Throwable $error) {
    error_log("CropSense transport key error: " . $error->getMessage());
    aes_save_response(["ok" => false, "error" => "Transport encryption is not configured."], 503);
}

$plaintext = openssl_decrypt(
    $ciphertext,
    "aes-256-gcm",
    $transportKey,
    OPENSSL_RAW_DATA,
    $iv,
    $tag,
    $aad
);

if ($plaintext === false) {
    aes_save_response(["ok" => false, "error" => "AES-GCM authentication/decryption failed."], 401);
}

$payload = json_decode($plaintext, true);
if (!is_array($payload) || json_last_error() !== JSON_ERROR_NONE) {
    aes_save_response(["ok" => false, "error" => "Decrypted sensor payload is invalid JSON."], 422);
}

if (trim((string) ($payload["device_id"] ?? "")) !== $deviceCode) {
    aes_save_response(["ok" => false, "error" => "Device identity mismatch."], 401);
}

[$validatedDeviceCode, $values] = cropsense_validate_sensor_values($payload, "aes_save_response");

$deviceName = substr(trim((string) ($payload["device_name"] ?? $validatedDeviceCode)), 0, 100);
$location = substr(trim((string) ($payload["location"] ?? "Field Station")), 0, 150);

try {
    $stored = cropsense_store_encrypted_reading(
        $conn,
        $validatedDeviceCode,
        $deviceName,
        $location,
        $values
    );
} catch (Throwable $error) {
    error_log("CropSense encrypted transport/database insert failed: " . $error->getMessage());
    aes_save_response(["ok" => false, "error" => "Unable to store encrypted sensor reading."], 500);
}

aes_save_response([
    "ok" => true,
    "message" => "Sensor reading encrypted in transit and at rest.",
    "id" => $stored["reading_id"],
    "device_id" => $validatedDeviceCode,
    "transport_encrypted" => true,
    "database_encrypted" => true,
    "transport_encryption" => "AES-256-GCM",
    "database_encryption" => "AES-256-GCM",
], 201);
