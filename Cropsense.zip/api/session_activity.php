<?php
require_once __DIR__ . '/../includes/security.php';
cropsense_apply_security_headers('api');
header('Allow: GET, POST');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET', 'POST'], true)) {
    http_response_code(405);
    echo json_encode(['ok' => false]);
    exit;
}
define('CROPSENSE_ACTIVITY_REQUEST', true);
require_once __DIR__ . '/../includes/session.php';
if ($method === 'POST') {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($token) || empty($_SESSION['activity_csrf']) ||
        !hash_equals($_SESSION['activity_csrf'], $token)) {
        http_response_code(403);
        echo json_encode(['ok' => false]);
        exit;
    }
    $_SESSION['last_activity'] = time();
}
// GET only checks expiry; background checks never count as interaction.
echo json_encode(['ok' => true, 'remaining' => max(0,
    CROPSENSE_SESSION_IDLE_SECONDS - (time() - $_SESSION['last_activity']))]);
