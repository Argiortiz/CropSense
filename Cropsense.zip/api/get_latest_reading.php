<?php
require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../includes/security.php";
require_once __DIR__ . "/../includes/storage_crypto.php";
require_once __DIR__ . "/../includes/crop_suitability.php";

cropsense_apply_security_headers("api");
header("Allow: GET");

function latest_response($body, $status = 200)
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER["REQUEST_METHOD"] ?? "GET") !== "GET") {
    latest_response(["ok" => false, "error" => "Method not allowed."], 405);
}

$deviceCode = trim((string) ($_GET["device_id"] ?? ""));
if ($deviceCode !== "" && !preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]{0,49}$/', $deviceCode)) {
    latest_response(["ok" => false, "error" => "Invalid device_id."], 422);
}

$sql = "
    SELECT
        sr.id,
        sr.soil_moisture,
        sr.temperature,
        sr.soil_ec,
        sr.soil_ph,
        sr.nitrogen,
        sr.phosphorus,
        sr.potassium,
        sr.humidity,
        sr.encrypted_payload,
        sr.encryption_iv,
        sr.encryption_tag,
        sr.encryption_version,
        sr.created_at,
        TIMESTAMPDIFF(SECOND, sr.created_at, NOW()) AS age_seconds,
        d.device_code,
        d.device_name
    FROM sensor_readings sr
    INNER JOIN devices d ON d.id = sr.device_id
";

$sql .= $deviceCode === "" ? "" : " WHERE d.device_code = ?";
$sql .= " ORDER BY sr.created_at DESC, sr.id DESC LIMIT 1";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("CropSense latest reading prepare failed.");
    latest_response(["ok" => false, "error" => "Unable to load sensor reading."], 500);
}

if ($deviceCode !== "") {
    $stmt->bind_param("s", $deviceCode);
}

if (!$stmt->execute()) {
    error_log("CropSense latest reading query failed.");
    $stmt->close();
    latest_response(["ok" => false, "error" => "Unable to load sensor reading."], 500);
}

$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) {
    latest_response(["ok" => true, "data" => null, "message" => "No sensor readings found."]);
}

try {
    $row = cropsense_decrypt_sensor_from_database($row);
} catch (Throwable $error) {
    error_log("CropSense latest reading AES decrypt failed: " . $error->getMessage());
    latest_response(["ok" => false, "error" => "Encrypted sensor reading could not be decrypted."], 500);
}

$age = max(0, (int) $row["age_seconds"]);

$data = [
    "id" => (int) $row["id"],
    "device_id" => $row["device_code"],
    "device_name" => $row["device_name"],
    "moisture" => (float) $row["soil_moisture"],
    "temperature" => (float) $row["temperature"],
    "ec" => (float) $row["soil_ec"],
    "ph" => (float) $row["soil_ph"],
    "nitrogen" => (float) $row["nitrogen"],
    "phosphorus" => (float) $row["phosphorus"],
    "potassium" => (float) $row["potassium"],
    "created_at" => $row["created_at"],
    "age_seconds" => $age,
    "connection_status" => $age <= 30 ? "Online" : ($age <= 60 ? "Stale" : "Offline"),
    "is_live" => $age <= 30,
    "storage_encrypted" => !empty($row["storage_encrypted"]),
    "storage_encryption" => !empty($row["storage_encrypted"]) ? "AES-256-GCM" : "LEGACY_PLAINTEXT",
];

// Preserve existing dashboard/API field names.
$data["soil_moisture"] = $data["moisture"];
$data["soil_ph"] = $data["ph"];
$data["soil_ec"] = $data["ec"];

if ($age > 60) {
    $offlineDeviceCode = $data["device_id"];
    $offlineUpdate = $conn->prepare(
        "UPDATE devices
         SET status = 'Offline'
         WHERE device_code = ?
           AND last_seen < DATE_SUB(NOW(), INTERVAL 60 SECOND)"
    );

    if ($offlineUpdate) {
        $offlineUpdate->bind_param("s", $offlineDeviceCode);
        $offlineUpdate->execute();
        $offlineUpdate->close();
    }
}

try {
    $data["crop_suitability"] = cropsense_assess_crop_suitability($conn, $data);
} catch (Throwable $error) {
    error_log("CropSense suitability assessment failed: " . $error->getMessage());
    $data["crop_suitability"] = [
        "title" => "Sensor-Based Crop Suitability Assessment",
        "error" => "Suitability assessment is temporarily unavailable.",
        "top_recommendation" => null,
        "recommendations" => [],
    ];
}

latest_response(["ok" => true, "data" => $data]);
