<?php
require_once __DIR__ . "/../includes/session.php";
require_once __DIR__ . "/../includes/roles.php";
require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../includes/storage_crypto.php";

if (!cropsense_is_admin()) {
    http_response_code(403);
    exit("Administrator access required.");
}

if (empty($_SESSION["db_aes_migration_csrf"])) {
    $_SESSION["db_aes_migration_csrf"] = bin2hex(random_bytes(32));
}

$message = "";

if (($_SERVER["REQUEST_METHOD"] ?? "GET") === "POST") {
    $token = (string) ($_POST["csrf_token"] ?? "");

    if (!hash_equals((string) $_SESSION["db_aes_migration_csrf"], $token)) {
        http_response_code(403);
        exit("Invalid CSRF token.");
    }

    $result = $conn->query(
        "SELECT
            sr.id,
            sr.soil_moisture,
            sr.soil_ph,
            sr.soil_ec,
            sr.nitrogen,
            sr.phosphorus,
            sr.potassium,
            sr.temperature,
            d.device_code
         FROM sensor_readings sr
         INNER JOIN devices d ON d.id = sr.device_id
         WHERE (sr.encrypted_payload IS NULL OR sr.encrypted_payload = '')
           AND sr.soil_moisture IS NOT NULL
         ORDER BY sr.id ASC
         LIMIT 100"
    );

    if (!$result) {
        $message = "Unable to read historical sensor rows.";
    } else {
        $processed = 0;
        $conn->begin_transaction();

        try {
            while ($row = $result->fetch_assoc()) {
                $values = [
                    "moisture" => (float) $row["soil_moisture"],
                    "temperature" => (float) $row["temperature"],
                    "ec" => (float) $row["soil_ec"],
                    "ph" => (float) $row["soil_ph"],
                    "nitrogen" => (float) $row["nitrogen"],
                    "phosphorus" => (float) $row["phosphorus"],
                    "potassium" => (float) $row["potassium"],
                ];

                $storage = cropsense_encrypt_sensor_for_database($values, $row["device_code"]);

                $update = $conn->prepare(
                    "UPDATE sensor_readings
                     SET
                        encrypted_payload = ?,
                        encryption_iv = ?,
                        encryption_tag = ?,
                        encryption_version = ?,
                        soil_moisture = NULL,
                        soil_ph = NULL,
                        soil_ec = NULL,
                        nitrogen = NULL,
                        phosphorus = NULL,
                        potassium = NULL,
                        temperature = NULL,
                        humidity = NULL
                     WHERE id = ?
                       AND (encrypted_payload IS NULL OR encrypted_payload = '')"
                );

                if (!$update) {
                    throw new RuntimeException("Unable to prepare historical migration update.");
                }

                $update->bind_param(
                    "sssii",
                    $storage["encrypted_payload"],
                    $storage["encryption_iv"],
                    $storage["encryption_tag"],
                    $storage["encryption_version"],
                    $row["id"]
                );

                if (!$update->execute()) {
                    throw new RuntimeException("Unable to encrypt a historical sensor row.");
                }

                if ($update->affected_rows > 0) {
                    $processed++;
                }

                $update->close();
            }

            $conn->commit();
            $message = "Encrypted {$processed} historical sensor row(s).";
        } catch (Throwable $error) {
            $conn->rollback();
            error_log("CropSense historical AES migration failed: " . $error->getMessage());
            $message = "Migration failed. This batch was rolled back.";
        }
    }
}

$countResult = $conn->query(
    "SELECT COUNT(*) AS remaining
     FROM sensor_readings
     WHERE (encrypted_payload IS NULL OR encrypted_payload = '')
       AND soil_moisture IS NOT NULL"
);

$remaining = $countResult ? (int) $countResult->fetch_assoc()["remaining"] : -1;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CropSense AES Migration</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f7f5;color:#15362d;padding:32px}
.card{max-width:720px;margin:auto;background:#fff;padding:28px;border-radius:16px;border:1px solid #dbe7e2}
.notice{background:#edf8f3;padding:12px;border-radius:8px}
button{background:#087a5b;color:#fff;border:0;border-radius:8px;padding:12px 18px;font-weight:700;cursor:pointer}
code{background:#eef3f1;padding:2px 5px;border-radius:4px}
</style>
</head>
<body>
<div class="card">
<h1>CropSense AES-256-GCM Historical Migration</h1>
<?php if ($message !== "") : ?>
<p class="notice"><?php echo htmlspecialchars($message); ?></p>
<?php endif; ?>

<p><strong>Remaining plaintext sensor rows:</strong>
<?php echo $remaining >= 0 ? number_format($remaining) : "Unknown"; ?></p>

<?php if ($remaining > 0) : ?>
<form method="post">
<input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION["db_aes_migration_csrf"]); ?>">
<button type="submit">Encrypt Next 100 Rows</button>
</form>
<?php else : ?>
<p class="notice"><strong>Migration complete.</strong> No historical plaintext sensor rows remain.</p>
<?php endif; ?>

<hr>
<p>After completion, delete:<br>
<code>tools/encrypt_existing_sensor_readings.php</code></p>
</div>
</body>
</html>
