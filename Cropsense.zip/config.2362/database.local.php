<?php

return [
    "host" => "localhost",
    "dbname" => "u910796166_cropsense_db",
    "username" => "u910796166_cs_admin",
    "password" => "1Mcwaterplease!",
];