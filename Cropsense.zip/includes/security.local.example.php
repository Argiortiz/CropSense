<?php
// Copy to security.local.php; preserve your existing device_api_key.
// Use a matching Google reCAPTCHA v2 "I'm not a robot" Checkbox key pair.
// Allowed domains: localhost and cropsense.site (no schemes, ports or paths).
return [
    'device_api_key' => 'YOUR_EXISTING_DEVICE_API_KEY',
    'recaptcha_site_key' => '', // Paste the v2 Checkbox Site Key here.
    'recaptcha_secret_key' => '', // Paste the matching Secret Key here.
];
