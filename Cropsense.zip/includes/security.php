<?php

$cropsenseSecurityConfig = [];
$cropsenseSecurityConfigPath = __DIR__ . '/../config/security.local.php';

if (is_file($cropsenseSecurityConfigPath)) {
    $loadedSecurityConfig = require $cropsenseSecurityConfigPath;

    if (is_array($loadedSecurityConfig)) {
        $cropsenseSecurityConfig = $loadedSecurityConfig;
    }
}

if (!defined('CROPSENSE_DEVICE_API_KEY')) {
    define(
        'CROPSENSE_DEVICE_API_KEY',
        getenv('CROPSENSE_DEVICE_API_KEY') ?: ($cropsenseSecurityConfig['device_api_key'] ?? '')
    );
}

if (!defined('CROPSENSE_RECAPTCHA_SITE_KEY')) {
    define(
        'CROPSENSE_RECAPTCHA_SITE_KEY',
        getenv('CROPSENSE_RECAPTCHA_SITE_KEY') ?: ($cropsenseSecurityConfig['recaptcha_site_key'] ?? '')
    );
}

if (!defined('CROPSENSE_RECAPTCHA_SECRET_KEY')) {
    define(
        'CROPSENSE_RECAPTCHA_SECRET_KEY',
        getenv('CROPSENSE_RECAPTCHA_SECRET_KEY') ?: ($cropsenseSecurityConfig['recaptcha_secret_key'] ?? '')
    );
}

if (!defined('CROPSENSE_SENSOR_AES_KEY_B64')) {
    define(
        'CROPSENSE_SENSOR_AES_KEY_B64',
        getenv('CROPSENSE_SENSOR_AES_KEY_B64') ?: ($cropsenseSecurityConfig['sensor_aes_key_base64'] ?? '')
    );
}

if (!defined('CROPSENSE_SENSOR_REQUIRE_ENCRYPTION')) {
    $envValue = getenv('CROPSENSE_SENSOR_REQUIRE_ENCRYPTION');
    $configValue = $cropsenseSecurityConfig['sensor_require_encryption'] ?? false;

    if ($envValue !== false && $envValue !== '') {
        $parsed = filter_var($envValue, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        $requireEncryption = $parsed ?? false;
    } else {
        $requireEncryption = (bool) $configValue;
    }

    define('CROPSENSE_SENSOR_REQUIRE_ENCRYPTION', $requireEncryption);
}

if (!defined('CROPSENSE_SENSOR_MAX_CLOCK_SKEW_MS')) {
    define('CROPSENSE_SENSOR_MAX_CLOCK_SKEW_MS', 300000);
}

if (!defined('CROPSENSE_MAX_SENSOR_PAYLOAD_BYTES')) {
    define('CROPSENSE_MAX_SENSOR_PAYLOAD_BYTES', 4096);
}

if (!function_exists('cropsense_csp_nonce')) {
    function cropsense_csp_nonce()
    {
        static $nonce = null;

        if ($nonce === null) {
            $nonce = base64_encode(random_bytes(18));
        }

        return $nonce;
    }
}

if (!function_exists('cropsense_start_secure_session')) {
    function cropsense_start_secure_session()
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'domain' => '',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);

        session_start();
    }
}


if (!defined('CROPSENSE_SESSION_TIMEOUT_SECONDS')) {
    define('CROPSENSE_SESSION_TIMEOUT_SECONDS', 1800); // 30 minutes
}

/*
|--------------------------------------------------------------------------
| Session-timeout compatibility constants
|--------------------------------------------------------------------------
| Production templates may reference CROPSENSE_SESSION_IDLE_SECONDS directly.
| Keep it aligned with the authoritative 30-minute timeout constant.
*/
if (!defined('CROPSENSE_SESSION_IDLE_SECONDS')) {
    define('CROPSENSE_SESSION_IDLE_SECONDS', CROPSENSE_SESSION_TIMEOUT_SECONDS);
}

if (!defined('CROPSENSE_SESSION_HEARTBEAT_SECONDS')) {
    define('CROPSENSE_SESSION_HEARTBEAT_SECONDS', 60);
}

if (!function_exists('cropsense_destroy_session_securely')) {
    function cropsense_destroy_session_securely()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            return;
        }

        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();

            setcookie(
                session_name(),
                '',
                [
                    'expires' => time() - 42000,
                    'path' => $params['path'] ?? '/',
                    'domain' => $params['domain'] ?? '',
                    'secure' => (bool) ($params['secure'] ?? false),
                    'httponly' => (bool) ($params['httponly'] ?? true),
                    'samesite' => $params['samesite'] ?? 'Lax',
                ]
            );
        }

        session_destroy();
    }
}

if (!function_exists('cropsense_enforce_session_timeout')) {
    function cropsense_enforce_session_timeout()
    {
        cropsense_start_secure_session();

        // Login / OTP sessions are not yet full authenticated sessions.
        if (empty($_SESSION['user_id'])) {
            return true;
        }

        $now = time();
        $lastActivity = isset($_SESSION['last_activity'])
            ? (int) $_SESSION['last_activity']
            : 0;

        // Backward-compatible initialization for sessions created before this patch.
        if ($lastActivity <= 0) {
            $_SESSION['last_activity'] = $now;
            return true;
        }

        if (($now - $lastActivity) >= CROPSENSE_SESSION_TIMEOUT_SECONDS) {
            cropsense_destroy_session_securely();

            if (!headers_sent()) {
                $loginUrl = function_exists('cropsense_url')
                    ? cropsense_url('login.php?reason=inactive')
                    : '/login.php?reason=inactive';

                header('Location: ' . $loginUrl);
            }

            exit();
        }

        // Deliberately DO NOT update last_activity here.
        // Background dashboard/API polling must not keep the user logged in.
        return true;
    }
}

if (!function_exists('cropsense_touch_session_activity')) {
    function cropsense_touch_session_activity()
    {
        cropsense_start_secure_session();

        if (empty($_SESSION['user_id'])) {
            return false;
        }

        $_SESSION['last_activity'] = time();
        return true;
    }
}

// Compatibility alias for older/newer heartbeat implementations.
if (!function_exists('cropsense_update_session_activity')) {
    function cropsense_update_session_activity()
    {
        return cropsense_touch_session_activity();
    }
}

if (!function_exists('cropsense_apply_security_headers')) {
    function cropsense_apply_security_headers($context = 'web')
    {
        if (headers_sent()) {
            return;
        }

        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: same-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');

        if ($context === 'api') {
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');
            return;
        }

        header(
            "Content-Security-Policy: " .
            "default-src 'self'; " .
            "script-src 'self' 'nonce-" . cropsense_csp_nonce() . "' https://cdn.jsdelivr.net https://www.google.com https://www.gstatic.com; " .
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; " .
            "font-src 'self' https://cdn.jsdelivr.net data:; " .
            "img-src 'self' data: https://images.unsplash.com https://www.gstatic.com https://www.google.com; " .
            "connect-src 'self' https://www.google.com https://www.gstatic.com; " .
            "frame-src https://www.google.com https://recaptcha.google.com; " .
            "frame-ancestors 'self'; " .
            "base-uri 'self'; " .
            "form-action 'self'"
        );
    }
}

if (!function_exists('cropsense_client_ip')) {
    function cropsense_client_ip()
    {
        return substr($_SERVER['REMOTE_ADDR'] ?? 'unknown', 0, 45);
    }
}

if (!function_exists('cropsense_audit_log')) {
    function cropsense_audit_log($conn, $userId, $activity)
    {
        if (!$conn || !$userId || !$activity) {
            return;
        }

        $safeActivity = substr((string) $activity, 0, 255);
        $ipAddress = cropsense_client_ip();
        $stmt = $conn->prepare('INSERT INTO audit_logs (user_id, activity, ip_address) VALUES (?, ?, ?)');

        if (!$stmt) {
            return;
        }

        $stmt->bind_param('iss', $userId, $safeActivity, $ipAddress);
        $stmt->execute();
        $stmt->close();
    }
}

if (!function_exists('cropsense_device_api_key_is_valid')) {
    function cropsense_device_api_key_is_valid($payload = [])
    {
        $expectedKey = CROPSENSE_DEVICE_API_KEY;

        if ($expectedKey === '') {
            return true;
        }

        $providedKey = $_SERVER['HTTP_X_API_KEY']
            ?? $_SERVER['HTTP_X_CROPSENSE_KEY']
            ?? ($payload['api_key'] ?? '');

        return is_string($providedKey) && hash_equals($expectedKey, $providedKey);
    }
}

if (!function_exists('cropsense_verify_recaptcha')) {
    function cropsense_verify_recaptcha($token)
    {
        $token = trim((string) $token);

        if (CROPSENSE_RECAPTCHA_SECRET_KEY === '' || $token === '') {
            return false;
        }

        $postData = http_build_query([
            'secret' => CROPSENSE_RECAPTCHA_SECRET_KEY,
            'response' => $token,
            'remoteip' => cropsense_client_ip(),
        ]);

        $responseBody = false;

        if (function_exists('curl_init')) {
            $curl = curl_init('https://www.google.com/recaptcha/api/siteverify');

            curl_setopt_array($curl, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $postData,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_TIMEOUT => 8,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/x-www-form-urlencoded',
                ],
            ]);

            $responseBody = curl_exec($curl);
            curl_close($curl);
        }

        if ($responseBody === false && filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) {
            $context = stream_context_create([
                'http' => [
                    'method' => 'POST',
                    'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
                    'content' => $postData,
                    'timeout' => 8,
                ],
            ]);

            $responseBody = @file_get_contents(
                'https://www.google.com/recaptcha/api/siteverify',
                false,
                $context
            );
        }

        if (!is_string($responseBody) || $responseBody === '') {
            error_log('CropSense reCAPTCHA verification request failed.');
            return false;
        }

        $result = json_decode($responseBody, true);

        return is_array($result) && !empty($result['success']);
    }
}

if (!function_exists('cropsense_sensor_aes_key')) {
    function cropsense_sensor_aes_key()
    {
        static $resolved = false;
        static $key = null;

        if ($resolved) {
            return $key;
        }

        $resolved = true;
        $encoded = trim((string) CROPSENSE_SENSOR_AES_KEY_B64);

        if ($encoded === '') {
            return null;
        }

        $decoded = base64_decode($encoded, true);

        if ($decoded === false || strlen($decoded) !== 32) {
            error_log('CropSense AES key must decode to exactly 32 bytes.');
            return null;
        }

        $key = $decoded;
        return $key;
    }
}

if (!function_exists('cropsense_decrypt_sensor_envelope')) {
    function cropsense_decrypt_sensor_envelope(array $envelope, &$error = null)
    {
        $error = null;

        if (!function_exists('openssl_decrypt')) {
            $error = 'OpenSSL is unavailable.';
            return null;
        }

        $key = cropsense_sensor_aes_key();
        if ($key === null) {
            $error = 'Sensor AES key is not configured correctly.';
            return null;
        }

        if (!in_array('aes-256-gcm', openssl_get_cipher_methods(), true)) {
            $error = 'AES-256-GCM is unavailable in OpenSSL.';
            return null;
        }

        $deviceCode = (string) ($envelope['device_id'] ?? '');
        $timestampMs = (string) ($envelope['timestamp_ms'] ?? '');
        $messageId = (string) ($envelope['message_id'] ?? '');

        $iv = base64_decode((string) ($envelope['iv'] ?? ''), true);
        $ciphertext = base64_decode((string) ($envelope['ciphertext'] ?? ''), true);
        $tag = base64_decode((string) ($envelope['tag'] ?? ''), true);

        if ($iv === false || strlen($iv) !== 12) {
            $error = 'Invalid AES-GCM IV.';
            return null;
        }

        if ($tag === false || strlen($tag) !== 16) {
            $error = 'Invalid AES-GCM authentication tag.';
            return null;
        }

        if ($ciphertext === false || $ciphertext === '') {
            $error = 'Invalid encrypted payload.';
            return null;
        }

        $aad = 'v1|' . $deviceCode . '|' . $timestampMs . '|' . $messageId;

        $plaintext = openssl_decrypt(
            $ciphertext,
            'aes-256-gcm',
            $key,
            OPENSSL_RAW_DATA,
            $iv,
            $tag,
            $aad
        );

        if ($plaintext === false) {
            $error = 'Encrypted payload authentication failed.';
            return null;
        }

        return $plaintext;
    }
}

?>
