<?php
require_once __DIR__ . "/../config/app_url.php";
require_once __DIR__ . "/security.php";

cropsense_start_secure_session();

if (!isset($_SESSION['user_id'])) {
    if (defined('CROPSENSE_ACTIVITY_REQUEST')) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Authentication required.']);
        exit();
    }
    header('Location: ' . cropsense_url('login.php'));
    exit();
}

require_once __DIR__ . "/../config/database.php";

if (!cropsense_enforce_session_timeout($conn, !defined('CROPSENSE_ACTIVITY_REQUEST'))) {
    if (defined('CROPSENSE_ACTIVITY_REQUEST')) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Session expired.']);
    } else {
        header('Location: ' . cropsense_url('login.php?reason=inactive'));
    }
    exit();
}

$sessionUserId = (int) $_SESSION['user_id'];
$sessionUserStatement = $conn->prepare("SELECT fullname, role, status FROM users WHERE id = ? LIMIT 1");
$sessionUser = null;

if ($sessionUserStatement) {
    $sessionUserStatement->bind_param("i", $sessionUserId);
    $sessionUserStatement->execute();
    $sessionUserResult = $sessionUserStatement->get_result();
    $sessionUser = $sessionUserResult ? $sessionUserResult->fetch_assoc() : null;
    $sessionUserStatement->close();
}

if (!$sessionUser || ($sessionUser['status'] ?? 'Inactive') !== 'Active') {
    cropsense_destroy_session();
    if (defined('CROPSENSE_ACTIVITY_REQUEST')) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Authentication required.']);
        exit();
    }
    header('Location: ' . cropsense_url('login.php'));
    exit();
}

$_SESSION['fullname'] = $sessionUser['fullname'];
$_SESSION['role'] = $sessionUser['role'];
?>
