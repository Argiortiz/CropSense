<?php
require_once __DIR__ . "/../config/app_url.php";

if (($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST") {
    header('Location: ' . cropsense_url('login.php'));
    exit();
}

require_once __DIR__ . "/security.php";
require_once __DIR__ . "/roles.php";

cropsense_start_secure_session();

require_once __DIR__ . "/../config/database.php";

$login = trim($_POST["username"] ?? "");
$password = trim($_POST["password"] ?? "");
$recaptchaToken = $_POST["g-recaptcha-response"] ?? "";

if (empty($login) || empty($password)) {
    $_SESSION['error'] = "Please enter your username/email and password.";
    header('Location: ' . cropsense_url('login.php'));
    exit();
}

if (CROPSENSE_RECAPTCHA_SECRET_KEY === '') {
    error_log('CropSense reCAPTCHA secret key is not configured.');
    $_SESSION['error'] = "Security verification is temporarily unavailable.";
    header('Location: ' . cropsense_url('login.php'));
    exit();
}

if (!cropsense_verify_recaptcha($recaptchaToken)) {
    $_SESSION['error'] = "Please complete the reCAPTCHA verification.";
    header('Location: ' . cropsense_url('login.php'));
    exit();
}

$sql = "SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    $_SESSION['error'] = "Login is not ready. Please check the database setup.";
    header('Location: ' . cropsense_url('login.php'));
    exit();
}

$stmt->bind_param("ss", $login, $login);
$stmt->execute();

$result = $stmt->get_result();

if (!$result) {
    $_SESSION['error'] = "Unable to check account. Please check the database setup.";
    header('Location: ' . cropsense_url('login.php'));
    exit();
}

if ($result->num_rows == 1) {
    $user = $result->fetch_assoc();

    if (($user['status'] ?? 'Active') !== 'Active') {
        $_SESSION['error'] = "Your account is inactive.";
        cropsense_audit_log($conn, (int) $user['id'], "Blocked login attempt for inactive account");
        header('Location: ' . cropsense_url('login.php'));
        exit();
    }

    if (password_verify($password, $user['password'])) {
        require_once __DIR__ . '/mailer.php';

        $invalidateOtp = $conn->prepare(
            "UPDATE login_otps
             SET used = 1
             WHERE user_id = ?
             AND used = 0"
        );

        if ($invalidateOtp) {
            $invalidateOtp->bind_param("i", $user['id']);
            $invalidateOtp->execute();
            $invalidateOtp->close();
        }

        $otp = (string) random_int(100000, 999999);
        $otpHash = password_hash($otp, PASSWORD_DEFAULT);
        $expiresAt = date('Y-m-d H:i:s', time() + 300);

        $otpStmt = $conn->prepare(
            "INSERT INTO login_otps
            (user_id, otp_hash, expires_at, attempts, used)
            VALUES (?, ?, ?, 0, 0)"
        );

        if (!$otpStmt) {
            $_SESSION['error'] = "Unable to prepare verification code.";
            header('Location: ' . cropsense_url('login.php'));
            exit();
        }

        $otpStmt->bind_param("iss", $user['id'], $otpHash, $expiresAt);

        if (!$otpStmt->execute()) {
            $_SESSION['error'] = "Unable to generate verification code.";
            header('Location: ' . cropsense_url('login.php'));
            exit();
        }

        $otpStmt->close();

        $emailSent = cropsenseSendOtp(
            $user['email'],
            $user['fullname'],
            $otp
        );

        if (!$emailSent) {
            $_SESSION['error'] = "Unable to send verification code. Please try again.";
            header('Location: ' . cropsense_url('login.php'));
            exit();
        }

        session_regenerate_id(true);

        $_SESSION['pending_2fa_user_id'] = (int) $user['id'];
        $_SESSION['pending_2fa_email'] = $user['email'];
        $_SESSION['otp_sent_at'] = time();

        cropsense_audit_log(
            $conn,
            (int) $user['id'],
            "Email OTP sent"
        );

        header('Location: ' . cropsense_url('otp.php'));
        exit();
    }

    $_SESSION['error'] = "Invalid username/email or password.";
    cropsense_audit_log($conn, (int) $user['id'], "Failed login attempt");
    header('Location: ' . cropsense_url('login.php'));
    exit();
}

$_SESSION['error'] = "Invalid username/email or password.";
header('Location: ' . cropsense_url('login.php'));
exit();
?>
