<?php
// Copy these keys into security.local.php; preserve your existing device key.
return [
    'device_api_key' => 'UXu7NvqVXEMtvDFH4F3fRo8F0VuW4RDJ',
    'recaptcha_site_key' => '6Lfb3NwtAAAAAKCdIOljCHqLLjg7has0agzKFF0A',
    'recaptcha_secret_key' => '6Lfb3NwtAAAAADhY09QAG5hBcB20J4HE2UA_hj74',
];
