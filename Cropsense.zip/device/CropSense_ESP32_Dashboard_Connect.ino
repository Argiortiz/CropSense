#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <time.h>
#include <sys/time.h>
#include <vector>
#include <cstring>
#include <esp_system.h>
#include <mbedtls/gcm.h>
#include <mbedtls/base64.h>

/*
=========================================================
                    CROPSENSE CONFIG
=========================================================
*/

// -------- Wi-Fi --------
const char *WIFI_SSID = "YOUR_WIFI_NAME";
const char *WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// -------- CropSense API --------
const char *API_URL =
    "https://cropsense.site/api/save_sensor_reading_aes.php";

const char *DEVICE_ID =
    "cropsense-esp32-01";

const char *API_KEY =
    "YOUR_DEVICE_API_KEY";

// -------- AES-256-GCM --------
// Must be EXACTLY the same as:
// public_html/config/security.local.php
// 'sensor_aes_key_base64' => '...'
const char *SENSOR_AES_KEY_B64 =
    "YOUR_BASE64_AES_256_KEY";

/*
=========================================================
                 TEMPORARY TLS TEST MODE
=========================================================

TRUE:
  Temporarily disables certificate verification.
  Use this only to determine whether HTTP -1 is caused
  by the current root certificate.

FALSE:
  Uses ROOT_CA certificate verification.

After successful diagnosis, set this to false and use
the correct current CA certificate.
*/
constexpr bool TLS_DIAGNOSTIC_INSECURE = true;

/*
=========================================================
                     HTTPS ROOT CA
=========================================================
*/

const char *ROOT_CA = R"PEM(
-----BEGIN CERTIFICATE-----
MIIFazCCA1OgAwIBAgIRAIIQz7DSQONZRGPgu2OCiwAwDQYJKoZIhvcNAQELBQAw
TzELMAkGA1UEBhMCVVMxKTAnBgNVBAoTIEludGVybmV0IFNlY3VyaXR5IFJlc2Vh
cmNoIEdyb3VwMRUwEwYDVQQDEwxJU1JHIFJvb3QgWDEwHhcNMTUwNjA0MTEwNDM4
WhcNMzUwNjA0MTEwNDM4WjBPMQswCQYDVQQGEwJVUzEpMCcGA1UEChMgSW50ZXJu
ZXQgU2VjdXJpdHkgUmVzZWFyY2ggR3JvdXAxFTATBgNVBAMTDElTUkcgUm9vdCBY
MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAK3oJHP0FDfzm54rVygc
h77ct984kIxuPOZXoHj3dcKi/vVqbvYATyjb3miGbESTtrFj/RQSa78f0uoxmyF+
0TM8ukj13Xnfs7j/EvEhmkvBioZxaUpmZmyPfjxwv60pIgbz5MDmgK7iS4+3mX6U
A5/TR5d8mUgjU+g4rk8Kb4Mu0UlXjIB0ttov0DiNewNwIRt18jA8+o+u3dpjq+sW
T8KOEUt+zwvo/7V3LvSye0rgTBIlDHCNAymg4VMk7BPZ7hm/ELNKjD+Jo2FR3qyH
B5T0Y3HsLuJvW5iB4YlcNHlsdu87kGJ55tukmi8mxdAQ4Q7e2RCOFvu396j3x+UC
B5iPNgiV5+I3lg02dZ77DnKxHZu8A/lJBdiB3QW0KtZB6awBdpUKD9jf1b0SHzUv
KBds0pjBqAlkd25HN7rOrFleaJ1/ctaJxQZBKT5ZPt0m9STJEadao0xAH0ahmbWn
OlFuhjuefXKnEgV4We0+UXgVCwOPjdAvBbI+e0ocS3MFEvzG6uBQE3xDk3SzynTn
jh8BCNAw1FtxNrQHusEwMFxIt4I7mKZ9YIqioymCzLq9gwQbooMDQaHWBfEbwrbw
qHyGO0aoSCqI3Haadr8faqU9GY/rOPNk3sgrDQoo//fb4hVC1CLQJ13hef4Y53CI
rU7m2Ys6xt0nUW7/vGT1M0NPAgMBAAGjQjBAMA4GA1UdDwEB/wQEAwIBBjAPBgNV
HRMBAf8EBTADAQH/MB0GA1UdDgQWBBR5tFnme7bl5AFzgAiIyBpY9umbbjANBgkq
hkiG9w0BAQsFAAOCAgEAVR9YqbyyqFDQDLHYGmkgJykIrGF1XIpu+ILlaS/V9lZL
ubhzEFnTIZd+50xx+7LSYK05qAvqFyFWhfFQDlnrzuBZ6brJFe+GnY+EgPbk6ZGQ
3BebYhtF8GaV0nxvwuo77x/Py9auJ/GpsMiu/X1+mvoiBOv/2X/qkSsisRcOj/KK
NFtY2PwByVS5uCbMiogziUwthDyC3+6WVwW6LLv3xLfHTjuCvjHIInNzktHCgKQ5
ORAzI4JMPJ+GslWYHb4phowim57iaztXOoJwTdwJx4nLCgdNbOhdjsnvzqvHu7Ur
TkXWStAmzOVyyghqpZXjFaH3pO3JLF+l+/+sKAIuvtd7u+Nxe5AW0wdeRlN8NwdC
jNPElpzVmbUq4JUagEiuTDkHzsxHpFKVK7q4+63SM1N95R1NbdWhscdCb+ZAJzVc
oyi3B43njTOQ5yOf+1CceWxG1bQVs5ZufpsMljq4Ui0/1lvh+wjChP4kqKOJ2qxq
4RgqsahDYVvTH9w7jXbyLeiNdd8XM2w9U/t7y0Ff/9yi0GE44Za4rF2LN9d11TPA
mRGunUHBcnWEvgJBQl9nJEiU0Zsnvgc/ubhPgXRR4Xq37Z0j4r7g1SgEEzwxA57d
emyPxgcYxn/eR44/KJ4EBs+lVDR3veyJm+kXQ99b21/+jh5Xos1AnX5iItreGCc=
-----END CERTIFICATE-----
)PEM";

/*
=========================================================
                      HARDWARE
=========================================================
*/

// MAX3485 / RS485
constexpr uint8_t RS485_RX = 16;
constexpr uint8_t RS485_TX = 17;
constexpr uint8_t RS485_DE_RE = 4;

// LCD I2C
constexpr uint8_t LCD_SDA = 21;
constexpr uint8_t LCD_SCL = 22;
constexpr uint8_t LCD_ADDRESS = 0x27;

LiquidCrystal_I2C lcd(LCD_ADDRESS, 16, 2);
HardwareSerial sensorSerial(2);

/*
=========================================================
                        TIMING
=========================================================
*/

constexpr uint32_t SENSOR_INTERVAL_MS = 1000;
constexpr uint32_t WIFI_RETRY_MS = 5000;
constexpr uint32_t MODBUS_TIMEOUT_MS = 1500;

unsigned long lastSensorAt = 0;
unsigned long lastWiFiAttemptAt = 0;

bool clockSynchronized = false;

/*
=========================================================
                    SOIL READING
=========================================================
*/

struct SoilReading {
    float moisture;
    float temperature;
    uint16_t ec;
    float ph;
    uint16_t nitrogen;
    uint16_t phosphorus;
    uint16_t potassium;
    bool valid;
};

/*
=========================================================
                       LCD HELPER
=========================================================
*/

void lcdShow(const String &line1, const String &line2) {
    lcd.clear();

    lcd.setCursor(0, 0);
    lcd.print(line1.substring(0, 16));

    lcd.setCursor(0, 1);
    lcd.print(line2.substring(0, 16));
}

/*
=========================================================
                      MODBUS CRC16
=========================================================
*/

uint16_t modbusCRC(const uint8_t *data, size_t length) {
    uint16_t crc = 0xFFFF;

    for (size_t i = 0; i < length; i++) {
        crc ^= data[i];

        for (uint8_t bit = 0; bit < 8; bit++) {
            if (crc & 0x0001) {
                crc >>= 1;
                crc ^= 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }

    return crc;
}

/*
=========================================================
                       WI-FI
=========================================================
*/

void maintainWiFi() {
    if (WiFi.status() == WL_CONNECTED) {
        return;
    }

    if (millis() - lastWiFiAttemptAt < WIFI_RETRY_MS) {
        return;
    }

    lastWiFiAttemptAt = millis();

    Serial.println("[WIFI] Reconnecting...");
    lcdShow("WiFi Offline", "Reconnecting");

    WiFi.disconnect();
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

/*
=========================================================
                       NTP CLOCK
=========================================================
*/

bool synchronizeClock() {
    if (clockSynchronized) {
        return true;
    }

    if (WiFi.status() != WL_CONNECTED) {
        return false;
    }

    Serial.println("[TIME] Synchronizing...");

    configTime(
        0,
        0,
        "pool.ntp.org",
        "time.google.com"
    );

    unsigned long started = millis();
    time_t now = time(nullptr);

    while (
        now < 1700000000 &&
        millis() - started < 10000
    ) {
        delay(100);
        now = time(nullptr);
    }

    clockSynchronized =
        now >= 1700000000;

    Serial.println(
        clockSynchronized
            ? "[TIME] Clock synchronized."
            : "[TIME] Clock synchronization failed."
    );

    return clockSynchronized;
}

/*
=========================================================
                    READ SOIL SENSOR
=========================================================
*/

bool readSoilSensor(SoilReading &reading) {
    reading.valid = false;

    // Slave 01, Function 03, Registers 0000-0006
    uint8_t request[8] = {
        0x01, 0x03,
        0x00, 0x00,
        0x00, 0x07,
        0x00, 0x00
    };

    uint16_t requestCRC =
        modbusCRC(request, 6);

    request[6] =
        requestCRC & 0xFF;

    request[7] =
        (requestCRC >> 8) & 0xFF;

    while (sensorSerial.available()) {
        sensorSerial.read();
    }

    // Transmit request
    digitalWrite(RS485_DE_RE, HIGH);
    delayMicroseconds(200);

    sensorSerial.write(
        request,
        sizeof(request)
    );

    sensorSerial.flush();

    // Immediately switch to receive
    digitalWrite(RS485_DE_RE, LOW);

    uint8_t response[19];
    size_t count = 0;
    unsigned long started = millis();

    while (
        millis() - started <
        MODBUS_TIMEOUT_MS
    ) {
        while (
            sensorSerial.available() &&
            count < sizeof(response)
        ) {
            response[count++] =
                sensorSerial.read();
        }

        if (count >= sizeof(response)) {
            break;
        }

        yield();
    }

    Serial.printf(
        "[SENSOR] Baud: 4800 | Response: %u bytes\n",
        (unsigned int) count
    );

    Serial.print("[SENSOR] Raw: ");

    for (size_t i = 0; i < count; i++) {
        if (response[i] < 0x10) {
            Serial.print("0");
        }

        Serial.print(
            response[i],
            HEX
        );

        if (i + 1 < count) {
            Serial.print(" ");
        }
    }

    Serial.println();

    if (count != sizeof(response)) {
        Serial.println(
            "[SENSOR] ERROR: Invalid response length."
        );

        lcdShow(
            "Sensor Error",
            "Check RS485"
        );

        return false;
    }

    uint16_t receivedCRC =
        response[17] |
        ((uint16_t) response[18] << 8);

    uint16_t calculatedCRC =
        modbusCRC(
            response,
            17
        );

    Serial.printf(
        "[SENSOR] Header: %02X %02X %02X | CRC RX:%04X CALC:%04X\n",
        response[0],
        response[1],
        response[2],
        receivedCRC,
        calculatedCRC
    );

    if (
        response[0] != 0x01 ||
        response[1] != 0x03 ||
        response[2] != 0x0E
    ) {
        Serial.println(
            "[SENSOR] ERROR: Invalid Modbus header."
        );

        lcdShow(
            "Modbus Error",
            "See Serial"
        );

        return false;
    }

    if (
        receivedCRC !=
        calculatedCRC
    ) {
        Serial.println(
            "[SENSOR] ERROR: CRC failed."
        );

        lcdShow(
            "CRC Error",
            "Check RS485"
        );

        return false;
    }

    uint16_t raw[7];

    for (uint8_t i = 0; i < 7; i++) {
        raw[i] =
            ((uint16_t)
                response[3 + i * 2] << 8)
            |
            response[4 + i * 2];
    }

    reading.moisture =
        raw[0] / 10.0f;

    reading.temperature =
        ((int16_t) raw[1]) / 10.0f;

    reading.ec =
        raw[2];

    reading.ph =
        raw[3] / 10.0f;

    reading.nitrogen =
        raw[4];

    reading.phosphorus =
        raw[5];

    reading.potassium =
        raw[6];

    reading.valid =
        reading.moisture >= 0 &&
        reading.moisture <= 100 &&
        reading.temperature >= -40 &&
        reading.temperature <= 85 &&
        reading.ph >= 0 &&
        reading.ph <= 14;

    return reading.valid;
}

/*
=========================================================
                     AES HELPERS
=========================================================
*/

String uint64ToString(uint64_t value) {
    char buffer[24];

    snprintf(
        buffer,
        sizeof(buffer),
        "%llu",
        (unsigned long long) value
    );

    return String(buffer);
}

uint64_t currentEpochMillis() {
    struct timeval tv;

    gettimeofday(
        &tv,
        nullptr
    );

    if (tv.tv_sec < 1700000000) {
        return 0;
    }

    return
        ((uint64_t) tv.tv_sec * 1000ULL) +
        ((uint64_t) tv.tv_usec / 1000ULL);
}

String hexEncode(
    const uint8_t *data,
    size_t length
) {
    static const char HEX_CHARS[] =
        "0123456789abcdef";

    String result;

    result.reserve(length * 2);

    for (size_t i = 0; i < length; i++) {
        result +=
            HEX_CHARS[
                (data[i] >> 4) & 0x0F
            ];

        result +=
            HEX_CHARS[
                data[i] & 0x0F
            ];
    }

    return result;
}

String base64Encode(
    const uint8_t *data,
    size_t length
) {
    size_t outputSize =
        4 * ((length + 2) / 3) + 5;

    std::vector<unsigned char>
        output(outputSize);

    size_t written = 0;

    int result =
        mbedtls_base64_encode(
            output.data(),
            output.size() - 1,
            &written,
            data,
            length
        );

    if (
        result != 0 ||
        written >= output.size()
    ) {
        return String();
    }

    output[written] = '\0';

    return String(
        (const char *) output.data()
    );
}

bool loadAesKey(uint8_t key[32]) {
    if (
        SENSOR_AES_KEY_B64 == nullptr ||
        strlen(SENSOR_AES_KEY_B64) == 0 ||
        String(SENSOR_AES_KEY_B64).startsWith("YOUR_")
    ) {
        Serial.println(
            "[AES] ERROR: AES key not configured."
        );

        return false;
    }

    size_t written = 0;

    int result =
        mbedtls_base64_decode(
            key,
            32,
            &written,
            (const unsigned char *)
                SENSOR_AES_KEY_B64,
            strlen(
                SENSOR_AES_KEY_B64
            )
        );

    if (
        result != 0 ||
        written != 32
    ) {
        Serial.println(
            "[AES] ERROR: Key must decode to exactly 32 bytes."
        );

        return false;
    }

    return true;
}

/*
=========================================================
                  AES-256-GCM ENCRYPT
=========================================================
*/

bool encryptSensorPayload(
    const String &plaintext,
    const String &deviceId,
    uint64_t timestampMs,
    const String &messageId,
    String &ivBase64,
    String &ciphertextBase64,
    String &tagBase64
) {
    uint8_t key[32];

    if (!loadAesKey(key)) {
        return false;
    }

    uint8_t iv[12];
    uint8_t tag[16];

    esp_fill_random(
        iv,
        sizeof(iv)
    );

    String aad =
        "v1|" +
        deviceId +
        "|" +
        uint64ToString(timestampMs) +
        "|" +
        messageId;

    std::vector<uint8_t>
        ciphertext(
            plaintext.length()
        );

    mbedtls_gcm_context context;
    mbedtls_gcm_init(&context);

    int result =
        mbedtls_gcm_setkey(
            &context,
            MBEDTLS_CIPHER_ID_AES,
            key,
            256
        );

    if (result == 0) {
        result =
            mbedtls_gcm_crypt_and_tag(
                &context,
                MBEDTLS_GCM_ENCRYPT,
                plaintext.length(),
                iv,
                sizeof(iv),
                (const unsigned char *)
                    aad.c_str(),
                aad.length(),
                (const unsigned char *)
                    plaintext.c_str(),
                ciphertext.data(),
                sizeof(tag),
                tag
            );
    }

    mbedtls_gcm_free(
        &context
    );

    memset(
        key,
        0,
        sizeof(key)
    );

    if (result != 0) {
        Serial.printf(
            "[AES] Encryption failed: %d\n",
            result
        );

        return false;
    }

    ivBase64 =
        base64Encode(
            iv,
            sizeof(iv)
        );

    ciphertextBase64 =
        base64Encode(
            ciphertext.data(),
            ciphertext.size()
        );

    tagBase64 =
        base64Encode(
            tag,
            sizeof(tag)
        );

    return
        ivBase64.length() > 0 &&
        ciphertextBase64.length() > 0 &&
        tagBase64.length() > 0;
}

/*
=========================================================
                  DASHBOARD UPLOAD
=========================================================
*/

bool uploadReading(
    const SoilReading &reading
) {
    if (
        !reading.valid ||
        WiFi.status() != WL_CONNECTED
    ) {
        return false;
    }

    if (!synchronizeClock()) {
        Serial.println(
            "[UPLOAD] Clock not ready."
        );

        return false;
    }

    uint64_t timestampMs =
        currentEpochMillis();

    if (timestampMs == 0) {
        return false;
    }

    uint8_t messageIdBytes[16];

    esp_fill_random(
        messageIdBytes,
        sizeof(messageIdBytes)
    );

    String messageId =
        hexEncode(
            messageIdBytes,
            sizeof(messageIdBytes)
        );

    String plaintext =
        "{\"device_id\":\"" +
        String(DEVICE_ID) +

        "\",\"moisture\":" +
        String(reading.moisture, 1) +

        ",\"temperature\":" +
        String(reading.temperature, 1) +

        ",\"ec\":" +
        String(reading.ec) +

        ",\"ph\":" +
        String(reading.ph, 1) +

        ",\"nitrogen\":" +
        String(reading.nitrogen) +

        ",\"phosphorus\":" +
        String(reading.phosphorus) +

        ",\"potassium\":" +
        String(reading.potassium) +

        "}";

    String ivBase64;
    String ciphertextBase64;
    String tagBase64;

    if (
        !encryptSensorPayload(
            plaintext,
            DEVICE_ID,
            timestampMs,
            messageId,
            ivBase64,
            ciphertextBase64,
            tagBase64
        )
    ) {
        Serial.println(
            "[UPLOAD] AES encryption failed."
        );

        return false;
    }

    String envelope =
        "{\"version\":1" +
        String(",\"device_id\":\"") +
        DEVICE_ID +
        "\"" +

        ",\"timestamp_ms\":" +
        uint64ToString(timestampMs) +

        ",\"message_id\":\"" +
        messageId +
        "\"" +

        ",\"iv\":\"" +
        ivBase64 +
        "\"" +

        ",\"ciphertext\":\"" +
        ciphertextBase64 +
        "\"" +

        ",\"tag\":\"" +
        tagBase64 +
        "\"" +

        "}";

    WiFiClientSecure client;

    if (TLS_DIAGNOSTIC_INSECURE) {
        client.setInsecure();

        Serial.println(
            "[TLS] WARNING: Diagnostic insecure mode ENABLED."
        );
    } else {
        client.setCACert(
            ROOT_CA
        );

        Serial.println(
            "[TLS] Certificate verification ENABLED."
        );
    }

    HTTPClient http;
    http.setTimeout(12000);

    Serial.println(
        "[HTTPS] Connecting to CropSense..."
    );

    if (
        !http.begin(
            client,
            API_URL
        )
    ) {
        Serial.println(
            "[HTTPS] http.begin() FAILED."
        );

        return false;
    }

    http.addHeader(
        "Content-Type",
        "application/json"
    );

    http.addHeader(
        "X-API-Key",
        API_KEY
    );

    int statusCode =
        http.POST(
            envelope
        );

    String response =
        http.getString();

    Serial.printf(
        "[UPLOAD] AES-256-GCM -> HTTP %d\n",
        statusCode
    );

    if (statusCode < 0) {
        Serial.printf(
            "[HTTP] ERROR: %s\n",
            http.errorToString(
                statusCode
            ).c_str()
        );
    }

    Serial.printf(
        "[SERVER] %s\n",
        response.c_str()
    );

    bool success =
        statusCode >= 200 &&
        statusCode < 300;

    http.end();

    return success;
}

/*
=========================================================
                         SETUP
=========================================================
*/

void setup() {
    Serial.begin(115200);
    delay(1000);

    Serial.println();
    Serial.println(
        "========================================"
    );
    Serial.println(
        " CropSense AES-256-GCM"
    );
    Serial.println(
        "========================================"
    );

    // LCD
    Wire.begin(
        LCD_SDA,
        LCD_SCL
    );

    lcd.init();
    lcd.backlight();

    lcdShow(
        "CropSense",
        "Starting..."
    );

    // RS485
    pinMode(
        RS485_DE_RE,
        OUTPUT
    );

    digitalWrite(
        RS485_DE_RE,
        LOW
    );

    sensorSerial.begin(
        4800,
        SERIAL_8N1,
        RS485_RX,
        RS485_TX
    );

    // Wi-Fi
    WiFi.mode(
        WIFI_STA
    );

    WiFi.begin(
        WIFI_SSID,
        WIFI_PASSWORD
    );

    lastWiFiAttemptAt =
        millis();

    Serial.printf(
        "[WIFI] Connecting to %s...\n",
        WIFI_SSID
    );
}

/*
=========================================================
                          LOOP
=========================================================
*/

void loop() {
    maintainWiFi();

    if (
        millis() - lastSensorAt <
        SENSOR_INTERVAL_MS
    ) {
        delay(1);
        return;
    }

    lastSensorAt =
        millis();

    Serial.println();
    Serial.println(
        "----------------------------------------"
    );

    if (
        WiFi.status() ==
        WL_CONNECTED
    ) {
        Serial.printf(
            "[WIFI] Connected | IP: %s\n",
            WiFi.localIP()
                .toString()
                .c_str()
        );
    } else {
        Serial.println(
            "[WIFI] Disconnected"
        );
    }

    SoilReading reading{};

    if (
        !readSoilSensor(
            reading
        )
    ) {
        Serial.println(
            "[SENSOR] Reading failed."
        );

        return;
    }

    Serial.printf(
        "[SENSOR] Moisture: %.1f %%\n",
        reading.moisture
    );

    Serial.printf(
        "[SENSOR] Temperature: %.1f C\n",
        reading.temperature
    );

    Serial.printf(
        "[SENSOR] EC: %u uS/cm\n",
        reading.ec
    );

    Serial.printf(
        "[SENSOR] pH: %.1f\n",
        reading.ph
    );

    Serial.printf(
        "[SENSOR] Nitrogen: %u mg/kg\n",
        reading.nitrogen
    );

    Serial.printf(
        "[SENSOR] Phosphorus: %u mg/kg\n",
        reading.phosphorus
    );

    Serial.printf(
        "[SENSOR] Potassium: %u mg/kg\n",
        reading.potassium
    );

    char line1[17];
    char line2[17];

    snprintf(
        line1,
        sizeof(line1),
        "M:%4.1f pH:%3.1f",
        reading.moisture,
        reading.ph
    );

    snprintf(
        line2,
        sizeof(line2),
        "T:%4.1f EC:%u",
        reading.temperature,
        reading.ec
    );

    lcdShow(
        String(line1),
        String(line2)
    );

    bool uploaded =
        uploadReading(
            reading
        );

    if (uploaded) {
        Serial.println(
            "[UPLOAD] SUCCESS"
        );

        lcdShow(
            "Dashboard: OK",
            "AES Upload OK"
        );
    } else {
        Serial.println(
            "[UPLOAD] FAILED"
        );

        lcdShow(
            "Upload Failed",
            "See Serial"
        );
    }
}
