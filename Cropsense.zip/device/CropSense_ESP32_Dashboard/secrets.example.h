#pragma once

// Copy this file to secrets.h and replace all placeholders.
// secrets.h must never be committed or uploaded publicly.

const char *WIFI_SSID = "YOUR_WIFI_NAME";
const char *WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

const char *API_KEY = "YOUR_EXISTING_DEVICE_API_KEY";

// Must be identical to Hostinger:
// config/security.local.php -> sensor_aes_key_base64
//
// Generate:
// C:\xampp\php\php.exe -r "echo base64_encode(random_bytes(32)), PHP_EOL;"
// or:
// openssl rand -base64 32
const char *SENSOR_AES_KEY_B64 = "PASTE_BASE64_32_BYTE_AES_KEY_HERE";
