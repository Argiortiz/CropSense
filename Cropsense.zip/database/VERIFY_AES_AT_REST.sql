-- AES-256-GCM database-at-rest evidence query.
-- For fully encrypted rows, readable telemetry columns should be NULL.

SELECT
    id,
    device_id,
    soil_moisture,
    soil_ph,
    soil_ec,
    nitrogen,
    phosphorus,
    potassium,
    temperature,
    LEFT(encrypted_payload, 80) AS encrypted_payload_preview,
    encryption_iv,
    encryption_tag,
    encryption_version,
    created_at
FROM sensor_readings
ORDER BY id DESC
LIMIT 10;
