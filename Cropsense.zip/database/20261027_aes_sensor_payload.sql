-- CropSense AES-256-GCM sensor-message replay protection
-- Run ONCE on the existing Hostinger database before enabling encrypted uploads.

ALTER TABLE `devices`
    ADD COLUMN `last_message_ts_ms` BIGINT UNSIGNED NULL AFTER `last_seen`;

CREATE INDEX `idx_devices_last_message_ts_ms`
    ON `devices` (`last_message_ts_ms`);
