-- CropSense: AES-256-GCM encrypted sensor data at rest
-- BACK UP THE DATABASE FIRST.
--
-- New readings will store the seven sensor measurements only in encrypted_payload.
-- The original numeric telemetry columns will be NULL for encrypted rows.

ALTER TABLE `sensor_readings`
    MODIFY `soil_moisture` DECIMAL(5,2) NULL,
    MODIFY `soil_ph` DECIMAL(4,2) NULL,
    MODIFY `soil_ec` DECIMAL(8,2) NULL DEFAULT NULL,
    MODIFY `nitrogen` DECIMAL(8,2) NULL,
    MODIFY `phosphorus` DECIMAL(8,2) NULL,
    MODIFY `potassium` DECIMAL(8,2) NULL,
    MODIFY `temperature` DECIMAL(5,2) NULL,
    MODIFY `humidity` DECIMAL(5,2) NULL,
    ADD COLUMN `encrypted_payload` LONGTEXT NULL AFTER `humidity`,
    ADD COLUMN `encryption_iv` VARCHAR(64) NULL AFTER `encrypted_payload`,
    ADD COLUMN `encryption_tag` VARCHAR(64) NULL AFTER `encryption_iv`,
    ADD COLUMN `encryption_version` TINYINT UNSIGNED NULL AFTER `encryption_tag`;
