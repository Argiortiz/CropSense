<?php
// EXAMPLE ONLY.
// Merge these settings into your EXISTING config/security.local.php.
// Never commit the real keys to GitHub.

return [
    "device_api_key" => "YOUR_EXISTING_DEVICE_API_KEY",

    // Existing ESP32 -> server AES-256-GCM key.
    "sensor_aes_key_base64" => "YOUR_EXISTING_TRANSPORT_AES_KEY",

    // NEW, DIFFERENT key for database-at-rest AES-256-GCM.
    "database_aes_key_base64" => "YOUR_NEW_DATABASE_AES_KEY",
];
