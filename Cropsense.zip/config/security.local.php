<?php

return [
    'device_api_key' => 'UXu7NvqVXEMtvDFH4F3fRo8F0VuW4RDJ',

    'recaptcha_site_key' => '6LcZgA4uAAAAAK_TAsJkwBYsUzxA1zOUsgCChxaF',

    'recaptcha_secret_key' => '6LcZgA4uAAAAAJpY6PjKwPcYCppOFBnSJ0kHGVn7',

    'sensor_aes_key_base64' => 'WdwG0cjQ6VZj5Ds9DF1/YDI/60ruk6MgLUXcBDML/nI=',
     'database_aes_key_base64' => "h3MZ8w+jc7KUEDkCk1HtYfHplUp7FlYQIckxFnMi4nY=",

    'sensor_require_encryption' => true,
];