<?php

return [
    'host' => 'smtp.hostinger.com',
    'username' => 'security@cropsense.site',
    'password' => '1Mcwaterplease!',
    'port' => 465,
    'encryption' => 'ssl',

    'from_email' => 'security@cropsense.site',
    'from_name' => 'CropSense Security'
];