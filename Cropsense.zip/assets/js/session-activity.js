// Activity tracking moved to session-timeout.js, loaded once by header.php.
