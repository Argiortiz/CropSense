(function () {
    "use strict";

    /* =========================================================
       CropSense live dashboard values
       - No page reload
       - Polls latest reading every 1 second
       - Only updates sensor/crop value elements
    ========================================================= */

    const API_URL = new URL(
        "api/get_latest_reading.php",
        window.location.href
    ).href;

    const POLL_INTERVAL_MS = 1000;

    let requestInProgress = false;
    let lastReadingId = null;

    /* =========================================================
       Helpers
    ========================================================= */

    function isPresent(value) {
        return value !== null && value !== undefined && value !== "";
    }

    function toNumber(value) {
        if (!isPresent(value)) {
            return null;
        }

        const parsed = Number(value);
        return Number.isFinite(parsed) ? parsed : null;
    }

    function numberText(value, decimals = 1) {
        const parsed = toNumber(value);
        return parsed === null ? "--" : parsed.toFixed(decimals);
    }

    function rawText(value) {
        return isPresent(value) ? String(value) : "--";
    }

    function percentageText(value) {
        const parsed = toNumber(value);
        return parsed === null ? "--" : parsed.toFixed(1) + "%";
    }

    function setText(selector, value) {
        document.querySelectorAll(selector).forEach(function (element) {
            if (element.textContent !== String(value)) {
                element.textContent = value;
            }
        });
    }

    function setTextInside(root, selector, value) {
        if (!root) {
            return;
        }

        const element = root.querySelector(selector);

        if (element && element.textContent !== String(value)) {
            element.textContent = value;
        }
    }

    /* =========================================================
       Live sensor values
    ========================================================= */

    function updateSensorValues(reading) {
        const moisture = reading.moisture ?? reading.soil_moisture;
        const temperature = reading.temperature;
        const ec = reading.ec ?? reading.soil_ec;
        const ph = reading.ph ?? reading.soil_ph;
        const nitrogen = reading.nitrogen;
        const phosphorus = reading.phosphorus;
        const potassium = reading.potassium;

        setText(
            '[data-reading="npk"]',
            rawText(nitrogen) + " / " + rawText(phosphorus) + " / " + rawText(potassium)
        );

        setText('[data-reading="nitrogen"]', rawText(nitrogen));
        setText('[data-reading="phosphorus"]', rawText(phosphorus));
        setText('[data-reading="potassium"]', rawText(potassium));
        setText('[data-reading="soil_moisture"]', numberText(moisture, 1));
        setText('[data-reading="soil_ph"]', numberText(ph, 1));
        setText('[data-reading="temperature"]', numberText(temperature, 1) + " °C");
        setText('[data-reading="soil_ec"]', numberText(ec, 0));
    }

    /* =========================================================
       Crop suitability values
       Updates text only; cards/layout are not reloaded or moved.
    ========================================================= */

    function updateCropValues(assessment) {
        if (!assessment || !Array.isArray(assessment.recommendations)) {
            return;
        }

        const recommendations = assessment.recommendations;

        if (!recommendations.length) {
            return;
        }

        let topCrop = recommendations[0];

        if (
            assessment.top_recommendation &&
            assessment.top_recommendation.crop_key
        ) {
            const matchedTop = recommendations.find(function (crop) {
                return crop.crop_key === assessment.top_recommendation.crop_key;
            });

            if (matchedTop) {
                topCrop = matchedTop;
            }
        }

        if (topCrop) {
            setText(
                "[data-recommendation-score]",
                percentageText(topCrop.percentage)
            );

            setText(
                "[data-recommendation-title]",
                (topCrop.crop || "Crop") + " — " + (topCrop.final_label || "Not Assessed")
            );

            setText(
                "[data-recommendation-class]",
                topCrop.final_label || "Not Assessed"
            );

            const topClass = String(topCrop.final_class || "").toUpperCase();

            setText(
                "[data-recommendation-description]",
                ["S1", "S2"].includes(topClass)
                    ? "Recommended for the current soil condition."
                    : "No crop currently reaches the Suitable classification for the measured soil condition."
            );
        }

        recommendations.forEach(function (crop, index) {
            if (!crop.crop_key) {
                return;
            }

            const card = document.querySelector(
                '[data-crop-assessment="' + crop.crop_key + '"]'
            );

            if (!card) {
                return;
            }

            setTextInside(
                card,
                "[data-crop-rank]",
                "#" + String(crop.rank || index + 1)
            );

            setTextInside(
                card,
                "[data-crop-percentage]",
                percentageText(crop.percentage)
            );

            setTextInside(
                card,
                "[data-crop-score]",
                String(crop.score ?? 0) + " / " + String(crop.maximum_score ?? 14)
            );

            setTextInside(
                card,
                "[data-crop-final-class]",
                crop.final_label || "Not Assessed"
            );

            setTextInside(
                card,
                "[data-crop-final-badge]",
                crop.final_label || "Not Assessed"
            );

            setTextInside(
                card,
                "[data-crop-assessed]",
                String(crop.assessed_parameters ?? 0) +
                    " of " +
                    String(crop.total_parameters ?? 7)
            );

            setTextInside(
                card,
                "[data-crop-match]",
                crop.match_explanation || ""
            );

            const missing = Array.isArray(crop.missing_parameters)
                ? crop.missing_parameters
                : [];

            setTextInside(
                card,
                "[data-crop-missing]",
                missing.length
                    ? "NO DATA: " + missing.join(", ") + "."
                    : ""
            );

            let limitingFactor = crop.limiting_factor_reason || "";

            if (
                !limitingFactor &&
                Array.isArray(crop.limiting_factors) &&
                crop.limiting_factors.length
            ) {
                limitingFactor = crop.limiting_factors[0].label || "";
            }

            setTextInside(
                card,
                "[data-crop-limiting-factor]",
                limitingFactor || "Not available"
            );

            const finalClass = String(crop.final_class || "").toUpperCase();

            setTextInside(
                card,
                "[data-crop-recommended]",
                index === 0 && ["S1", "S2"].includes(finalClass)
                    ? "Recommended for current soil condition."
                    : ""
            );
        });
    }

    /* =========================================================
       Apply one latest API reading
    ========================================================= */

    function updateDashboardValues(reading) {
        if (!reading) {
            return;
        }

        updateSensorValues(reading);

        if (reading.crop_suitability) {
            updateCropValues(reading.crop_suitability);
        }
    }

    /* =========================================================
       Fetch newest reading every second
    ========================================================= */

    async function fetchLatestReading() {
        if (requestInProgress) {
            return;
        }

        requestInProgress = true;

        try {
            const separator = API_URL.includes("?") ? "&" : "?";
            const requestUrl = API_URL + separator + "_=" + Date.now();

            const response = await fetch(requestUrl, {
                method: "GET",
                cache: "no-store",
                credentials: "same-origin",
                headers: {
                    "Accept": "application/json"
                }
            });

            if (!response.ok) {
                throw new Error("HTTP " + response.status);
            }

            const payload = await response.json();

            if (!payload || payload.ok !== true || !payload.data) {
                return;
            }

            const reading = payload.data;
            const readingId = isPresent(reading.id) ? String(reading.id) : null;

            /*
             * Poll every second, but only change the DOM when a newer
             * sensor row is received. This keeps the dashboard stable.
             */
            if (readingId !== null && readingId === lastReadingId) {
                return;
            }

            lastReadingId = readingId;
            updateDashboardValues(reading);

        } catch (error) {
            console.error("CropSense live-value update failed:", error);
        } finally {
            requestInProgress = false;
        }
    }

    /* =========================================================
       Start
    ========================================================= */

    function startLiveValues() {
        fetchLatestReading();
        window.setInterval(fetchLatestReading, POLL_INTERVAL_MS);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", startLiveValues, {
            once: true
        });
    } else {
        startLiveValues();
    }

    document.addEventListener("visibilitychange", function () {
        if (!document.hidden) {
            fetchLatestReading();
        }
    });
})();
