(function () {
    "use strict";

    const API_URL = new URL(
        "api/get_latest_reading.php",
        window.location.href
    ).href;

    const REFRESH_MS = 1000;

    let loading = false;

    function setValue(selector, value) {
        const element = document.querySelector(selector);

        if (element) {
            element.textContent =
                value !== null &&
                value !== undefined &&
                value !== ""
                    ? value
                    : "--";
        }
    }

    async function refreshNpk() {
        if (loading) {
            return;
        }

        loading = true;

        try {
            const response = await fetch(
                API_URL + "?_=" + Date.now(),
                {
                    method: "GET",
                    cache: "no-store",
                    headers: {
                        "Accept": "application/json"
                    }
                }
            );

            if (!response.ok) {
                throw new Error(
                    "HTTP " + response.status
                );
            }

            const result = await response.json();

            if (
                !result ||
                result.ok !== true ||
                !result.data
            ) {
                return;
            }

            const data = result.data;

            const nitrogen =
                data.nitrogen ?? "--";

            const phosphorus =
                data.phosphorus ?? "--";

            const potassium =
                data.potassium ?? "--";

            /* Update individual NPK values */

            setValue(
                '[data-reading="nitrogen"]',
                nitrogen
            );

            setValue(
                '[data-reading="phosphorus"]',
                phosphorus
            );

            setValue(
                '[data-reading="potassium"]',
                potassium
            );

            /* Update combined NPK value */

            setValue(
                '[data-reading="npk"]',
                nitrogen +
                    " / " +
                    phosphorus +
                    " / " +
                    potassium
            );

        } catch (error) {
            console.error(
                "CropSense NPK live update:",
                error
            );

        } finally {
            loading = false;
        }
    }

    /* Load immediately */
    refreshNpk();

    /* Update NPK every 1 second */
    setInterval(
        refreshNpk,
        REFRESH_MS
    );

})();