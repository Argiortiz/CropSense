(function () {
    const dashboard = document.querySelector("[data-live-dashboard]");

    if (!dashboard) {
        return;
    }

    const apiUrl = "api/sensor_readings.php";
    const pollMs = 1000;

    const setText = (selector, value) => {
        document.querySelectorAll(selector).forEach((element) => {
            element.textContent = value;
        });
    };

    const setSystemStatus = (status, label) => {
        const pill = document.querySelector("[data-system-pill]");
        const text = document.querySelector("[data-system-label]");

        if (text) {
            text.textContent = label;
        }

        if (pill) {
            pill.classList.toggle("is-offline", status === "offline");
            pill.classList.toggle("is-stale", status === "stale");
        }
    };

    const numberValue = (value) => {
        const parsed = Number(value);
        return Number.isFinite(parsed) ? parsed : null;
    };

    const fixed = (value, digits = 1) => {
        const parsed = numberValue(value);
        return parsed === null ? "--" : parsed.toFixed(digits);
    };

    const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

    const rangeScore = (value, min, max) => {
        const parsed = numberValue(value);

        if (parsed === null) {
            return 0;
        }

        if (parsed >= min && parsed <= max) {
            return 100;
        }

        const distance = parsed < min ? min - parsed : parsed - max;
        const tolerance = Math.max(1, (max - min) * 0.7);

        return clamp(Math.round(100 - (distance / tolerance) * 100), 0, 100);
    };

    const percentText = (value) => `${fixed(value, 0)}%`;
    const celsiusText = (value) => `${fixed(value, 1)} C`;
    const nutrientText = (value) => fixed(value, 0);

    const relativeTime = (ageSeconds) => {
        const age = numberValue(ageSeconds);

        if (age === null) {
            return "just now";
        }

        if (age < 60) {
            return "just now";
        }

        if (age < 3600) {
            return `${Math.floor(age / 60)} min ago`;
        }

        return `${Math.floor(age / 3600)} hr ago`;
    };

    const setBar = (name, score) => {
        document.querySelectorAll(`[data-readiness-bar="${name}"]`).forEach((bar) => {
            bar.style.setProperty("--readiness-width", `${clamp(score, 0, 100)}%`);
        });
    };

    const showEmptyState = () => {
        setText('[data-reading="soil_moisture"]', "--%");
        setText('[data-reading="soil_ph"]', "--");
        setText('[data-reading="soil_ec"]', "--");
        setText('[data-reading="npk"]', "-- / -- / --");
        setText('[data-reading="nitrogen"]', "--");
        setText('[data-reading="phosphorus"]', "--");
        setText('[data-reading="potassium"]', "--");
        setText('[data-reading="temperature"]', "-- C");
        setText('[data-reading="humidity"]', "--%");

        setText('[data-reading-status="soil_moisture"]', "Awaiting sensor reading");
        setText('[data-reading-status="soil_ph"]', "pH sensor not connected");
        setText('[data-reading-status="soil_ec"]', "Electrical conductivity");
        setText('[data-reading-status="npk"]', "Awaiting NPK sensor reading");
        setText('[data-reading-status="temperature"]', "Field climate reading");
        setText('[data-reading-status="humidity"]', "Air moisture status");

        setText("[data-recommendation-score]", "--");
        setText("[data-recommendation-title]", "No crop selected yet");
        setText("[data-activity-title]", "Sensor readings pending");
        setText("[data-activity-detail]", "Waiting for device input");
        setSystemStatus("offline", "Sensor Offline");

        setBar("moisture", 0);
        setBar("nutrients", 0);
        setBar("climate", 0);
    };

    const updateDashboard = (reading) => {
        if (!reading) {
            showEmptyState();
            return;
        }

        const nitrogen = numberValue(reading.nitrogen) || 0;
        const phosphorus = numberValue(reading.phosphorus) || 0;
        const potassium = numberValue(reading.potassium) || 0;
        const soilPh = numberValue(reading.soil_ph) || 0;
        const soilEc = numberValue(reading.soil_ec) || 0;
        const npk = `${nutrientText(nitrogen)} / ${nutrientText(phosphorus)} / ${nutrientText(potassium)}`;
        const updatedAt = relativeTime(reading.age_seconds);
        const isLive = reading.is_live === true || reading.is_live === "1" || reading.connection_status === "Live";
        const freshnessLabel = isLive ? `Updated ${updatedAt}` : `Last reading ${updatedAt}`;

        setText('[data-reading="soil_moisture"]', percentText(reading.soil_moisture));
        setText('[data-reading="soil_ph"]', soilPh > 0 ? fixed(soilPh, 1) : "--");
        setText('[data-reading="soil_ec"]', soilEc > 0 ? fixed(soilEc, 0) : "--");
        setText('[data-reading="npk"]', npk);
        setText('[data-reading="nitrogen"]', nutrientText(nitrogen));
        setText('[data-reading="phosphorus"]', nutrientText(phosphorus));
        setText('[data-reading="potassium"]', nutrientText(potassium));
        setText('[data-reading="temperature"]', celsiusText(reading.temperature));
        setText('[data-reading="humidity"]', percentText(reading.humidity));

        setText('[data-reading-status="soil_moisture"]', freshnessLabel);
        setText('[data-reading-status="soil_ph"]', soilPh > 0 ? freshnessLabel : "pH sensor not connected");
        setText('[data-reading-status="soil_ec"]', soilEc > 0 ? `uS/cm ${freshnessLabel.toLowerCase()}` : "Electrical conductivity");
        setText('[data-reading-status="npk"]', `N, P, K mg/kg ${isLive ? "updated" : "last updated"} ${updatedAt}`);
        setText('[data-reading-status="temperature"]', freshnessLabel);
        setText('[data-reading-status="humidity"]', freshnessLabel);

        const moistureScore = rangeScore(reading.soil_moisture, 35, 75);
        const climateScore = Math.round((
            rangeScore(reading.temperature, 22, 34) +
            rangeScore(reading.humidity, 45, 85)
        ) / 2);
        const nutrientScore = clamp(Math.round(((nitrogen + phosphorus + potassium) / 150) * 100), 0, 100);
        const overallScore = Math.round((moistureScore + climateScore + nutrientScore) / 3);

        setBar("moisture", moistureScore);
        setBar("nutrients", nutrientScore);
        setBar("climate", climateScore);

        setText("[data-recommendation-score]", `${overallScore}%`);
        setText("[data-recommendation-title]", isLive
            ? (overallScore >= 70 ? "Field profile looks ready" : "More readings needed")
            : "Waiting for live sensor update");
        setText("[data-activity-title]", isLive ? "Live sensor reading received" : "Sensor offline");
        setText("[data-activity-detail]", `${reading.device_name || "CropSense device"} ${isLive ? "updated" : "last updated"} ${updatedAt}`);
        setSystemStatus(isLive ? "live" : "offline", isLive ? "Sensor Live" : "Sensor Offline");
    };

    const loadLatestReading = async () => {
        try {
            const response = await fetch(apiUrl, { cache: "no-store" });

            if (!response.ok) {
                throw new Error("Reading request failed");
            }

            const payload = await response.json();

            if (!payload.ok) {
                throw new Error(payload.error || "Invalid sensor response");
            }

            updateDashboard(payload.data);
        } catch (error) {
            setText("[data-activity-title]", "Unable to refresh readings");
            setText("[data-activity-detail]", "Check the local server and database connection");
            setSystemStatus("stale", "Server Check Failed");
        }
    };

    loadLatestReading();
    window.setInterval(loadLatestReading, pollMs);
})();
