(function () {
    const ready = (callback) => {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", callback, { once: true });
            return;
        }

        callback();
    };

    ready(() => {
        const root = document.documentElement;
        const body = document.body;
        const themeToggle = document.getElementById("themeToggle");
        const fontSizeRange = document.getElementById("fontSizeRange");
        const fontSizeValue = document.getElementById("fontSizeValue");
        const sidebarToggles = document.querySelectorAll("[data-sidebar-toggle]");
        const sidebarBrand = document.querySelector("[data-sidebar-brand]");
        const passwordToggles = document.querySelectorAll("[data-password-toggle]");
        const dataFilterLinks = document.querySelectorAll(".data-filter-more a");
        const confirmButtons = document.querySelectorAll("[data-confirm-message]");
        const logoImages = document.querySelectorAll("[data-logo-image]");

        const readPreference = (key, fallback) => {
            try {
                return localStorage.getItem(key) || fallback;
            } catch (error) {
                return fallback;
            }
        };

        const savePreference = (key, value) => {
            try {
                localStorage.setItem(key, value);
            } catch (error) {
                // Storage can be blocked in private modes; the UI should still work.
            }
        };

        const applyTheme = (theme) => {
            body.classList.toggle("theme-dark", theme === "dark");
            savePreference("cropsenseTheme", theme);
        };

        const applyFontSize = (fontSize) => {
            const normalizedSize = Math.min(20, Math.max(14, Number(fontSize) || 16));
            root.style.setProperty("--dashboard-font-size", `${normalizedSize}px`);
            savePreference("cropsenseFontSize", String(normalizedSize));

            if (fontSizeRange) {
                fontSizeRange.value = String(normalizedSize);
            }

            if (fontSizeValue) {
                fontSizeValue.textContent = `${normalizedSize}px`;
            }
        };

        const applySidebar = (state) => {
            const isCollapsed = state === "closed";
            body.classList.toggle("sidebar-collapsed", isCollapsed);
            savePreference("cropsenseSidebar", isCollapsed ? "closed" : "open");

            sidebarToggles.forEach((button) => {
                button.setAttribute("aria-expanded", String(!isCollapsed));
                button.setAttribute("aria-label", isCollapsed ? "Expand sidebar" : "Collapse sidebar");
                button.setAttribute("title", isCollapsed ? "Expand sidebar" : "Collapse sidebar");
            });

            if (sidebarBrand) {
                sidebarBrand.setAttribute("aria-label", isCollapsed ? "Open sidebar" : "CropSense dashboard");
                sidebarBrand.setAttribute("title", isCollapsed ? "Open sidebar" : "CropSense dashboard");
            }
        };

        const savedTheme = readPreference("cropsenseTheme", "light");
        const savedFontSize = readPreference("cropsenseFontSize", "16");
        const savedSidebar = readPreference("cropsenseSidebar", "open");

        applyTheme(savedTheme);
        applyFontSize(savedFontSize);
        applySidebar(savedSidebar);

        logoImages.forEach((image) => {
            const markMissing = () => image.classList.add("is-missing");

            if (image.complete && image.naturalWidth === 0) {
                markMissing();
            }

            image.addEventListener("error", markMissing);
        });

        if (themeToggle) {
            themeToggle.checked = savedTheme === "dark";
            themeToggle.addEventListener("change", () => {
                applyTheme(themeToggle.checked ? "dark" : "light");
            });
        }

        if (fontSizeRange) {
            fontSizeRange.addEventListener("input", () => {
                applyFontSize(fontSizeRange.value);
            });
        }

        document.addEventListener("click", (event) => {
            const toggleButton = event.target.closest("[data-sidebar-toggle]");

            if (toggleButton) {
                event.preventDefault();
                applySidebar(body.classList.contains("sidebar-collapsed") ? "open" : "closed");
                return;
            }

            const brand = event.target.closest("[data-sidebar-brand]");

            if (brand && body.classList.contains("sidebar-collapsed")) {
                event.preventDefault();
                applySidebar("open");
            }
        });

        passwordToggles.forEach((button) => {
            button.addEventListener("click", () => {
                const input = document.getElementById(button.dataset.passwordToggle);
                const icon = button.querySelector("i");

                if (!input || !icon) {
                    return;
                }

                const isHidden = input.type === "password";
                input.type = isHidden ? "text" : "password";
                button.setAttribute("aria-label", isHidden ? "Hide temporary password" : "Show temporary password");
                button.setAttribute("aria-pressed", String(isHidden));
                icon.classList.toggle("bi-eye", !isHidden);
                icon.classList.toggle("bi-eye-slash", isHidden);
            });
        });

        dataFilterLinks.forEach((link) => {
            link.addEventListener("click", () => {
                const menu = link.closest("details");

                if (menu) {
                    menu.open = false;
                }
            });
        });

        confirmButtons.forEach((button) => {
            button.addEventListener("click", (event) => {
                if (button.disabled) {
                    return;
                }

                if (!window.confirm(button.dataset.confirmMessage)) {
                    event.preventDefault();
                }
            });
        });
    });
})();
